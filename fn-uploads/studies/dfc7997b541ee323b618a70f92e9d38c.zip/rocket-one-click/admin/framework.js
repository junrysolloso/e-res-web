var ioc_admin = {}; 
var ioc_reminded_ssl = false;


(function(){
	ioc_admin_app = angular.module('iocAdmin', []);
	ioc_admin.load = new jQuery.Deferred();
	ioc_admin_app.controller('iocAdminCtrl', ['$scope','$http', function ($scope, $http) {
		ioc_admin.ctrl = this;
		ioc_admin.scope = $scope;
		ioc_admin.http = $http;

		

		// load apps:
		$scope.infusion_apps = ioc_resources.infusion_apps;
		$scope.infusedwoo_present = ioc_resources.infusedwoo_present;
		$scope.checkingupdates = true;
		load_available_apps($scope.infusion_apps, ioc_resources.set_app);


		ioc_admin.load.resolve();
		/*** INITIALIZATION ***/
		$http({
		    url: ajaxurl, 
		    method: "GET",
		    params: {action: 'ioc_admin_init'}	
		}).success(function(data) {
			$scope.license = data.license;
			$scope.updatecheck = data.updatecheck;
			$scope.licensekey = data.license.key;
			$scope.nextversion = data.nextversion;
			if(!data.license.key) {
				$scope.license = {};
				$scope.license.invalid = 1;
				position_popup();
			} else if(data.license.invalid) {
				position_popup();
			}
			$scope.checkingupdates = false;
			jQuery(".ioc_advanced_settings").show();
		}).error(function() {
			$scope.httperror = true;
			$scope.checkingupdates = false;
		});


		/*** SAVING OF LICENSE KEY ***/
		$scope.license_save = function(key) {
			$scope.license_checking = true;
			$http({
			    url: (ajaxurl + "?action=ioc_admin_license_save"), 
			    method: "POST",
			    data: jQuery.param({key: key}),
			    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
			}).success(function(data) {
				$scope.license = data.license;
				$scope.license_checking = false;
			}).error(function() {
				$scope.httperror = true;
				$scope.license_checking = false;
			});
		};

		/*** SAVING OF INFUSIONSOFT APP ***/
		$scope.save_app = function(appname, apikey) {
			if(appname && apikey) {
				$scope.saving_app = true;
				$scope.save_status = {};
				$http({
				    url: (ajaxurl + "?action=ioc_admin_app_save"), 
				    method: "POST",
				    data: jQuery.param({appname: appname, apikey: apikey}),
				    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
				}).success(function(data) {
					$scope.save_status = data;
					if(!data.error) {
						$scope.infusion_apps = data.allapps;
						load_available_apps(data.allapps, data.app);
						$scope.addnewapp = false;
					}
					$scope.saving_app = false;
				}).error(function() {
					$scope.httperror = true;
					$scope.save_status = {error: 'Cannot connect to Infusionsoft at this time.'};
					$scope.saving_app = false;
				});
			} else {
				$scope.save_status = {error: 'Please make sure App name and API key are not empty.'};
			}
		};

		$scope.test_app = function(appname, apikey) {
			if(appname && apikey) {
				$scope.saving_app = true;
				$scope.save_status = {};
				$http({
				    url: (ajaxurl + "?action=ioc_admin_app_test"), 
				    method: "POST",
				    data: jQuery.param({appname: appname, apikey: apikey}),
				    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
				}).success(function(data) {
					$scope.save_status = data;
					if(!data.error) {
						var app_el = jQuery(".infusion_app_" + data.app);
						if(app_el.length > 0) {
							 jQuery(".infusion_app_" + data.app + " input.editkey").val(data.key);
							 $scope.addnewapp = false;
						} else {
							var newapp = '<div class="infusion_app infusion_app_'+data.app+'">';
							newapp += '<img src="'+ioc_resources.plugin_url+'lib/images/ifsapp2.png"><span class="ia-app-text">'+data.app+'.infusionsoft.com</span>';
							newapp += '<input type="hidden" name="infusion_appnames[]" class="editapp" value="'+data.app+'" />';
							newapp += '<input type="hidden" name="infusion_appkey[]" class="editkey" value="'+data.key+'" />';
							newapp += '<div class="ia-app-control">';
							newapp += '<span class="ia-app-edit"><i class="fa fa-pencil-square-o"></i></span>\n';
							newapp += '<span class="ia-app-del"><i class="fa fa-trash-o"></i></span>';
							newapp += '</div></div>';
							jQuery(".infusion_apps").append(newapp);
						}
						$scope.addnewapp = false;
						infusion_apps_changed();
					}
					$scope.saving_app = false;

				}).error(function() {
					$scope.httperror = true;
					$scope.save_status = {error: 'Cannot connect to Infusionsoft at this time.'};
					$scope.saving_app = false;
				});
			} else {
				$scope.save_status = {error: 'Please make sure App name and API key are not empty.'};
			}
		};


		$scope.admin_edit_app = function(appname, apikey) {
			$scope.apikey = apikey;
			$scope.appname = appname;

			$scope.addnewapp = true;
			$scope.saving_app = false;
			$scope.save_status = {};
			position_popup();

		};



		$scope.addnewapp_popup = function() {
			$scope.appname = "";
			$scope.apikey = "";
			$scope.addnewapp = true;
			$scope.saving_app = false;
			$scope.save_status = {};
			position_popup();
		};

		$scope.closeapp_popup = function() {
			$scope.addnewapp = false;
			load_available_apps($scope.infusion_apps);
		}

		$scope.check_upsell_filter = function(upsell_name) {
			if($scope.upsell_filter) {
				upsell_name = upsell_name.toLowerCase();
				upsell_filter = $scope.upsell_filter.toLowerCase();
				if(upsell_name.indexOf(upsell_filter.trim()) > -1) {
					return true;
				} else {
					return false;
				}
			} else {
				return true;
			}
		}
	}]);

	jQuery(".ui-toggle").click(function(e) {
	        e.preventDefault();
	        if(jQuery(this).hasClass('checked')) {
	            jQuery(this).removeClass('checked');
	        } else {
	            jQuery(this).addClass('checked');
	        }
	    }); 

	jQuery(".addproduct").click( function() {
		var newline = "";
		newline += '<tr class="prodfield">';
		newline += '	<td><input type="text" class="prodsearch" name="prodname[]" style="width: 300px" placeholder="Start typing to search product..." />';
		newline += '		<input type="hidden" class="prodid" name="prods[]" />';
		newline += '	</td>';
		newline += '	<td>';
		newline += '		<input type="text" class="prodprice payplan_control reqnumber" name="prodprice[]" style="width: 120px" placeholder="Product Price" />';
		newline += '	</td>';
		newline += '	<td><i class="fa fa-times-circle"></i></td>';
		newline += '</tr>';
		jQuery(".productlist tbody").append(newline);
		enable_prod_autocomplete(jQuery(".prodsearch:last"));
	});	
	recalc_totals();
	enable_prod_autocomplete(jQuery(".prodsearch"));

	jQuery("body").on('keyup', '.prodprice', function() {
		recalc_totals();
	});

	jQuery("body").on('keyup', '.customfee', function() {
		recalc_totals();
	});

	jQuery("body").on('click', '.prodfield .fa-times-circle', function() {
		jQuery(this).closest(".prodfield").remove();
		recalc_totals();
	});

	// button appearance
	update_button_preview();
	jQuery(".button-control select").change( function() {
		update_button_preview();
	});

	jQuery(".button-control [name=button-text]").keyup(function(){
		update_button_preview();
	});

	// tab-structure
	jQuery(".tab-structure .tab-content").hide();
	jQuery(".tab-structure").find(".tab-content:first").show();

	jQuery(".tab-structure .tab").click(function() {
		var ind = jQuery(this).index();
		jQuery(this).closest(".tab-structure").find(".tab-content").hide();
		jQuery(this).closest(".tab-structure").find(".tab-content:eq("+ind+")").show();

		jQuery(this).closest(".tab-structure").find(".tab").removeClass("active");
		jQuery(this).addClass("active");
	});

	// tag and action set search
	enable_multi_autocomplete(jQuery(".tagsearch"), 'tags');
	enable_multi_autocomplete(jQuery(".declinetags"), 'tags','declinetag');

	enable_multi_autocomplete(jQuery(".actionsearch"), 'actions');
	enable_multi_autocomplete(jQuery(".declinesearch"), 'actions','decline');


	jQuery("body").on('click', '.del_li', function() {
		jQuery(this).closest("li").remove();
	});

	// custom uploader
	var custom_uploader;
	jQuery('#upload_image_button').click(function(e) {
 
        e.preventDefault();
 
        //If the uploader object has already been created, reopen the dialog
        if (custom_uploader) {
            custom_uploader.open();
            return;
        }
 
        //Extend the wp.media object
        custom_uploader = wp.media.frames.file_frame = wp.media({
            title: 'Choose Image',
            button: {
                text: 'Choose Image'
            },
            multiple: false
        });
 
        //When a file is selected, grab the URL and set it as the text field's value
        custom_uploader.on('select', function() {
            attachment = custom_uploader.state().get('selection').first().toJSON();
            jQuery('#upload_image').val(attachment.url);
        });
 
        //Open the uploader dialog
        custom_uploader.open();
 
    });


    // embed upsell
    jQuery(".embed_upsell").click(function() {
    	jQuery(this).parent().find(".embed-instr").slideDown();
    });

    jQuery(".hide-embed-code").click(function() {
    	jQuery(this).parent().slideUp();
    });

    // advanced appearance
    jQuery(".advanced-appearance").click( function(e) {
    	e.preventDefault();
    	jQuery(".advanced-content").toggle();

    	if(jQuery(".advanced-content").is(":visible")) {
    		jQuery(this).find(".fa").removeClass("fa-caret-square-o-right");
    		jQuery(this).find(".fa").addClass("fa-caret-square-o-down");
    	} else {
    		jQuery(this).find(".fa").removeClass("fa-caret-square-o-down");
    		jQuery(this).find(".fa").addClass("fa-caret-square-o-right");
    	}
    });
    refresh_advanced_embed();
    jQuery("[name=advanced-embed]").change( function() {
    	refresh_advanced_embed();
    });


	// submission and validation
	jQuery(".ia-submit").click(function() {
		var validation_results = validate_submission();

		if(validation_results) {
			var form_data = jQuery(".upsell_edit").serializeArray();

			// Upsellid
			form_data.push({name: 'upsellid', value: ioc_resources.upsellid});

			// Append Infusionsoft App
			form_data.push({name: 'infusion_app', value: ioc_resources.infusion_app});

			// manual charge:
			form_data.push({name: 'manual_charge', value: jQuery("[name=manual_charge]").hasClass('checked') });

			// confirmation dialog:
			form_data.push({name: 'conf_dialog', value: jQuery("[name=conf_dialog]").hasClass('checked') });

			jQuery(".ia-submit").addClass("ia-disable");
			jQuery(".ia-submit").html('<span class="ia-button-text ia-large">Saving...</span>');

			jQuery.post(ioc_resources.ajaxurl + "?action=ioc_upsell_submit", form_data, function(data) {
				if(data.success) {
					jQuery(".upsell_saved").slideDown();
					jQuery(".upsell_saved .save_success").fadeIn();

					setTimeout(function() {
						jQuery(".upsell_saved .save_success").fadeOut();
					}, 4000)
				} else {
					swal('Unexpected Error','Cannot save upsell at this time. Please try again, otherwise contact support.','error');
				}

				jQuery(".ia-submit").removeClass("ia-disable");
				jQuery(".ia-submit").html('<span class="ia-button-text ia-large">Save and Embed</span>');
			}, 'json');
		}
		//submit_form_data(form_data);

		//jQuery(".upsell_saved").slideDown();
	});

	jQuery(".ia-save-settings").click(function() {
		var form_data = jQuery(".ioc_advanced_settings").serializeArray();
		form_data.push({name: 'processing_order', value: jQuery("[name=processing_order]").hasClass('checked') });
		form_data.push({name: 'allow_new_cc', value: jQuery("[name=allow_new_cc]").hasClass('checked') });
		form_data.push({name: 'obtain_from_wp_user', value: jQuery("[name=obtain_from_wp_user]").hasClass('checked') });
		form_data.push({name: 'notify_purchases', value: jQuery("[name=notify_purchases]").hasClass('checked') });
		form_data.push({name: 'notify_failures', value: jQuery("[name=notify_failures]").hasClass('checked') });

		jQuery(".ia-save-settings").addClass("ia-disable");
		jQuery(".ia-save-settings").html('<span class="ia-button-text ia-large">Saving...</span>');

		jQuery.post(ioc_resources.ajaxurl + "?action=ioc_save_settings", form_data, function(data) {
				if(data.success) {
					jQuery(".settings_saved").slideDown();
					jQuery(".save_reminder").hide();

					setTimeout(function() {
						jQuery(".settings_saved").fadeOut();
					}, 4000);
				} else {
					swal('Unexpected Error','Cannot save upsell at this time. Please try again, otherwise contact support.','error');
				}

				jQuery(".ia-save-settings").removeClass("ia-disable");
				jQuery(".ia-save-settings").html('<span class="ia-button-text ia-large">Save Settings</span>');
		}, 'json');
	});

	// require number:
	jQuery("body").on("keypress", ".reqnumber", function(event) {
		return isNumberKey(event);
	});

	// payplan refresh
	payplan_preview_refresh();
	jQuery("body").on('keyup', '.payplan_control', function() {
		payplan_preview_refresh();
	});

	jQuery("body").on('change', '.payplan_control', function() {
		payplan_preview_refresh();
	});

	// product type
	refresh_product_type();
	jQuery("[name=product_type]").change(function() {
		refresh_product_type();
	});


	// advanced product 
	jQuery(".advanced-product").click( function(e) {
    	e.preventDefault();
    	var type = jQuery("[name=product_type]").val();
    	jQuery("." + type +".advanced").toggle();

    	if(jQuery("." + type +".advanced").is(":visible")) {
    		jQuery(this).find(".fa").removeClass("fa-caret-square-o-right");
    		jQuery(this).find(".fa").addClass("fa-caret-square-o-down");
    		payplan_preview_refresh();
    	} else {
    		jQuery(this).find(".fa").removeClass("fa-caret-square-o-down");
    		jQuery(this).find(".fa").addClass("fa-caret-square-o-right");
    	}
    });

    // delete upsell confirm
    jQuery(".delete-alert").click(function(e) {
    	e.preventDefault();
    	var thishref = jQuery(this).attr("href");

    	swal({   
    		title: "Are you sure?",   
    		text: "You are about to delete an upsell. Please confirm.",   
    		type: "warning",   
    		showCancelButton: true,   
    		confirmButtonColor: "#DD6B55",   
    		confirmButtonText: "Yes, delete it!",   
    		cancelButtonText: "No, cancel",  
    		closeOnConfirm: false,   
    	}, function(isConfirm){   
    		if (isConfirm) {     
    			location.href = thishref;  
    		} 
    	});
    });	


    jQuery('body').on('click','.ia-app-edit', function() {
		var appname = jQuery(this).parent().parent().children(".editapp").val();
		var apikey = jQuery(this).parent().parent().children(".editkey").val();

		ioc_admin.scope.appname = appname;
		ioc_admin.scope.apikey = apikey;


    	ioc_admin.scope.$apply( function() {
    		ioc_admin.scope.addnewapp = true;
			ioc_admin.scope.saving_app = false;
			ioc_admin.scope.save_status = {};
			position_popup();
    	});
    });

    jQuery('body').on('click','.ia-app-add', function() {
		ioc_admin.scope.appname = "";
		ioc_admin.scope.apikey = "";


    	ioc_admin.scope.$apply( function() {
    		ioc_admin.scope.addnewapp = true;
			ioc_admin.scope.saving_app = false;
			ioc_admin.scope.save_status = {};
			position_popup();
    	});
    });


     jQuery('body').on('click','.ia-app-del', function() {
		jQuery(this).parent().parent().remove();
		infusion_apps_changed();
    });

     jQuery(".use_ssl_wp").click( function() {
     	ioc_remind_ssl();
		if(jQuery(this).hasClass("checked")) {
			jQuery(this).parent().parent().find(".use_ssl_show").show();
		} else {
			jQuery(this).parent().parent().find(".use_ssl_show").hide();
		}
	});

     jQuery(".use_ssl_nonwp").click( function() {
     	ioc_remind_ssl();
		if(jQuery(this).hasClass("checked")) {
			var code_js = jQuery(this).parent().parent().find(".code_js").html();
			var re = new RegExp("http:", 'g');
			var new_code = code_js.replace(re,"https:");
			jQuery(this).parent().parent().find(".code_js").html(new_code);
		} else {
			var code_js = jQuery(this).parent().parent().find(".code_js").html();
			var re = new RegExp("https:", 'g');
			var new_code = code_js.replace(re,"http:");
			jQuery(this).parent().parent().find(".code_js").html(new_code);
		}
	});

     // Conditional Redirs
     jQuery("#conditionalRedir").animatedModal({
     	animatedIn: 'bounceIn',
     	animatedOut: 'bounceOut'
     });

     jQuery(".ia-manage-smartlinks").click(function() {
     	jQuery(".use-smartlink").css('visibility','hidden');
		ioc_admin.scope.$apply( function() {
			ioc_admin.scope.load_existing_smartlinks();
		});
     });

     jQuery('[name=conf_dialog]').click(function() {
     	if(jQuery(this).hasClass('checked')) {
     		jQuery(".conf-dialog-msg").show();
     	} else {
     		jQuery(".conf-dialog-msg").hide();
     	}
     });

     jQuery('.preview_dialog').click(function() {
     	swal({   
     		title: "Please Confirm",   
     		text: jQuery('[name=conf_dialog_msg]').val(),   
     		type: "warning",   
     		showCancelButton: true,   
     		confirmButtonColor: "#76D21C",   
     		confirmButtonText: "Continue",   
     		closeOnConfirm: false 
     	});

     	return false;
     });

     jQuery('.addlineitem').click(function() {
     	var newlineitem = '<div class="row customlineitem">';							
		newlineitem += '	<div class="one-third">';
		newlineitem += '		<select name="customline[]">';
		newlineitem += '			<option value="">Select Line Item Type ...</option>';
		newlineitem += '			<option>Tax</option>';
		newlineitem += '			<option>Shipping</option>';
		newlineitem += '			<option>Discount</option>';
		newlineitem += '			<option>Custom Charge</option>';
		newlineitem += '		</select>';
		newlineitem += '	</div>';
		newlineitem += '	<div class="one-third">';
		newlineitem += '		<div class="setting_input"><input type="text" name="customlinedesc[]" placeholder="Line Description" value="" /></div>';
		newlineitem += '	</div>';
		newlineitem += '	<div class="one-third">';
		newlineitem += '		<div class="setting_input">';
		newlineitem += '		<input type="text" name="customlinefee[]" placeholder="Fee Amount" value="" class="reqnumber customfee" /><i class="fa fa-times-circle del_cusli"></i>';
		newlineitem += '		</div>';
		newlineitem += '	</div>	';
		newlineitem += '</div>';

		jQuery('.customlineitems').append(newlineitem);
     });

     jQuery("body").on('click', '.del_cusli', function() {
     	jQuery(this).closest('.customlineitem').remove();
     	recalc_totals();
     });

})();

function ioc_remind_ssl() {
	if(!ioc_reminded_ssl) {
		ioc_reminded_ssl = true;
		swal('Make sure your site is SSL ready', 'To use SSL connection for your upsells, please make sure that your site is SSL ready. If you\'re not sure, please contact your server admin.', 'warning');
	}
}

function infusion_apps_changed() {
	jQuery(".save_reminder").slideDown();
}

function refresh_product_type() {
	var type = jQuery("[name=product_type]").val();

	jQuery(".single-prod, .bundled-prod, .subscription").hide();
	jQuery("." + type).show();
	jQuery("." + type +".advanced").hide();

	jQuery(".advanced-product").find(".fa").removeClass("fa-caret-square-o-down");
	jQuery(".advanced-product").find(".fa").addClass("fa-caret-square-o-right");

	// show advanced if some setting is set.
	if(type == 'single-prod' || type == 'bundled-prod') {
		if(jQuery("[name=numofpayments]").val()) {
			jQuery("." + type +".advanced").show();
			jQuery(".advanced-product").find(".fa").addClass("fa-caret-square-o-down");
			jQuery(".advanced-product").find(".fa").removeClass("fa-caret-square-o-right");
			payplan_preview_refresh();
		}
	} else if(type == 'subscription') {
		if(jQuery("[name=freetrial]").val() || jQuery("[name=signupfee]").val()) {
			jQuery("." + type +".advanced").show();
			jQuery(".advanced-product").find(".fa").addClass("fa-caret-square-o-down");
			jQuery(".advanced-product").find(".fa").removeClass("fa-caret-square-o-right");
			payplan_preview_refresh();
		}
	}
}

function no_payplan(total) {
	jQuery(".payplan .payplan_preview table").show();
	jQuery(".payplan .payplan_error").hide();
	var preview_html = "<tr><td>Paid Immediately</td><td>" + parseFloat(Math.round(total * 100) / 100).toFixed(2) + "</td><td></td></tr>";
	jQuery(".payplan .payplan_preview table tbody").html(preview_html);
}

function payplan_preview_refresh() {
	var payplan_errors = [];
	var total = jQuery("[name=single_prodprice]").val();
	var type = jQuery("[name=product_type]").val();

	if(type == 'single-prod' || type == 'bundled-prod') {
		if(type == 'bundled-prod') total = parseFloat(jQuery(".totalvalue").html());

		if(total <= 0) {
			no_payplan(total);
			return false;
		}

		if(!jQuery("[name=numofpayments]").val() || jQuery("[name=numofpayments]").val() <= 0) {
			no_payplan(total);
			return false;
		}
		if(!jQuery("[name=daysbetween]").val() || jQuery("[name=daysbetween]").val() <= 0) {
			no_payplan(total);
			return false;
		}
		if(parseFloat(jQuery("[name=initpay]").val()) > total) 
			payplan_errors.push("Required Initial Payment should not be greater than Product Price");
		if(jQuery("[name=numofpayments]").val() > 100) {
			payplan_errors.push("Number of payments should not be more than 100");
		} 


		if(payplan_errors.length > 0) {
			var show_error = payplan_errors.join("<br>");
			jQuery(".payplan .payplan_preview table").hide();
			jQuery(".payplan .payplan_error").show();
			jQuery(".payplan .payplan_error").html("<span class='errorhead'>Check the following errors to preview payment plan:</span><br>" + show_error);
		} else {
			jQuery(".payplan .payplan_preview table").show();
			jQuery(".payplan .payplan_error").hide();

			// calculation
			var initpay = jQuery("[name=initpay]").val() ? parseFloat(jQuery("[name=initpay]").val()) : 0;
			var remaining = total - initpay;
			var numpayments = parseInt(jQuery("[name=numofpayments]").val());
			var recurring = remaining / (numpayments - 1);
			recurring = parseFloat(Math.round(recurring * 100) / 100).toFixed(2)
			var daysbetween  = parseInt(jQuery("[name=daysbetween]").val());

			var preview_html = "<tr><td>Paid Immediately</td><td>" + parseFloat(Math.round(initpay * 100) / 100).toFixed(2) + "</td><td></td></tr>";
			for(i = 1; i <= numpayments-1; i++) {
				var days_after = daysbetween * i;
				preview_html += "<tr><td>";
				preview_html += days_after;
				preview_html += " days after</td><td>";
				preview_html += recurring;
				preview_html += "</td><td></td></tr>";
			}

			jQuery(".payplan .payplan_preview table tbody").html(preview_html);

		} 
	} else if(type == 'subscription') {
		var signupfee = jQuery('[name=signupfee]').val();
		signupfee = signupfee ? parseFloat(signupfee) : 0;

		var trialdays = jQuery('[name=freetrial]').val();
		trialdays = trialdays ? parseInt(trialdays) : 0;

		var recurring = parseFloat(total);
		var billnum = parseInt(jQuery('[name="billcycle_num"]').val());
		var numcycles = parseInt(jQuery('[name="numofcycles"]').val());
		var billcycle = jQuery('[name="billcycle"]').val();


		if(trialdays > 0) var paid_today = signupfee;
		else var paid_today = signupfee + recurring;

		var preview_html = "<tr><td>Paid Immediately</td><td>" + parseFloat(Math.round(paid_today * 100) / 100).toFixed(2) + "</td><td></td></tr>";

		if(trialdays > 0) {
			var day_string = trialdays > 1 ? "days" : "day";
			preview_html += "<tr><td>In "+ trialdays +" "+day_string+"</td><td>" + parseFloat(Math.round(recurring * 100) / 100).toFixed(2) + "</td><td></td></tr>";
		}

		if(numcycles > 1 || numcycles == 0) {
			var timeframe = billnum > 1 ? billcycle + 's' : billcycle;
			preview_html += "<tr><td>Every "+billnum+" "+timeframe+" thereafter</td><td>" + parseFloat(Math.round(recurring * 100) / 100).toFixed(2);
			if(numcycles > 1) preview_html += " (recurs "+ (numcycles-1) +" times)";
			else preview_html += " (recurs until cancelled)";
			preview_html += "</td><td></td></tr>";
		}

		jQuery(".payplan .payplan_preview table tbody").html(preview_html);

	}

	update_button_preview();
}



function validate_submission() {
	validation_errors = [];

	// check upsell name
	if(jQuery('[name=upsell_name]').val() == '') {
		validation_errors.push("Upsell Name is Empty.");
	} 

	// check ty page url
	if(jQuery('[name=ty_url]').val() == '') {
		validation_errors.push("Thank You page URL is empty");
	} 

	// check merchant id
	if(jQuery('[name=merchantid]').val() == '') {
		validation_errors.push("Merchant ID is empty. This is required.");
	} 


	// check application
	if(!ioc_resources.infusion_app) {
		validation_errors.push("No Infusionsoft application was chosen.");
	}

	// check products
	var type = jQuery("[name=product_type]").val();

	if(type == 'bundled-prod') {
		var product_names = jQuery(".bundled-prod .prodsearch");
		for(var i = 0; i < product_names.length; i++) {
			if(!jQuery(product_names[i]).val()) {
				validation_errors.push("Some of the product name fields are empty.");
				break;
			}
		}
	

		var product_ids = jQuery(".bundled-prod .prodid");
		for(var i = 0; i < product_ids.length; i++) {
			if(!jQuery(product_ids[i]).val()) {
				validation_errors.push("Some of the products entered can't be found in Infusionsoft.");
				break;
			}
		}

		var product_prices = jQuery(".bundled-prod .prodprice");
		for(var i = 0; i < product_prices.length; i++) {
			if(!jQuery(product_prices[i]).val()) {
				validation_errors.push("Some of the product price fields are empty.");
				break;
			}
		}
	} else {
		if(!jQuery('[name=single_prod]').val()) {
			validation_errors.push("You did not enter the product.");
		}

		if(!jQuery('[name=prodid]').val()) {
			validation_errors.push("The product you entered can't be found in Infusionsoft.");
		}
	}

	if(validation_errors.length > 0) {
		var validation_errors_string = validation_errors.join("\n");
		swal('Form Errors. Please check below.', validation_errors_string, 'warning');
	} else {
		return true;
	}

}

function refresh_advanced_embed() {
	var adv_option = jQuery("[name=advanced-embed]").val();

	jQuery(".custom-adv").hide();
	if(adv_option == 'link')  jQuery(".custom-text-adv").show();
	else if(adv_option == 'image') jQuery(".custom-image-adv").show();

	if(adv_option == 'link' || adv_option == 'image') {
		if(jQuery(".advanced-content").is(":not(:visible)")) {
			jQuery(".advanced-content").toggle();
			jQuery(".advanced-appearance").find(".fa").addClass("fa-caret-square-o-down");
			jQuery(".advanced-appearance").find(".fa").removeClass("fa-caret-square-o-right");
		}
	}
}

function update_button_preview() {
	jQuery(".button-preview > a").removeClass();
	jQuery(".button-preview > a").addClass("ia-button");
	jQuery(".button-preview > a .ia-button-icon").hide();

	// update color:
	var color = jQuery("[name=button-color]").val();
	jQuery(".button-preview > a").addClass("ia-" + color);

	// update theme
	var theme = jQuery("[name=button-theme]").val();
	jQuery(".button-preview > a").addClass("ia-" + theme);

	// update icon
	var icon = jQuery("[name=button-icon]").val();
	if(icon) {
		jQuery(".button-preview > a .ia-button-icon").show();
		jQuery(".button-preview > a .ia-button-icon i").removeClass();
		jQuery(".button-preview > a .ia-button-icon i").addClass("fa");
		jQuery(".button-preview > a .ia-button-icon i").addClass("fa-"+icon);
	}

	// update size
	var size = jQuery("[name=button-size]").val();
	jQuery(".button-preview > a").addClass("ia-" + size);

	// show price or not
	var show_price = jQuery("[name=button-show-price]").val();
	var total = parseFloat(jQuery("[name=single_prodprice]").val());

	if(show_price == 'no') jQuery(".ia-button-price").hide();
	else {
		var type = jQuery("[name=product_type]").val();
		jQuery(".button-preview .ia-button-price").show();

		if(type == 'single-prod' || type == 'bundled-prod') {		
			if(type == 'bundled-prod') total = jQuery(".totalvalue").html();
			total = jQuery("[name=initpay]").val() ? parseFloat(jQuery("[name=initpay]").val()) : total;
		} else if(type == 'subscription') {
			var signupfee = jQuery('[name=signupfee]').val();
			signupfee = signupfee ? parseFloat(signupfee) : 0;

			var trialdays = jQuery('[name=freetrial]').val();
			trialdays = trialdays ? parseInt(trialdays) : 0;

			if(trialdays > 0) total = signupfee;
			else total = total + signupfee;
		}

		// Custom Fees
		var cl = jQuery('.customlineitem');
		for(var c = 0; c < cl.length; c++) {
			var linetype = jQuery(cl[c]).find('.customlinetype').val();
			if(linetype == 'Discount') {
				total -= parseFloat(jQuery(cl[c]).find('.customfee').val());
			} else if(linetype != '') {
				total += parseFloat(jQuery(cl[c]).find('.customfee').val());
			}
		}

		total = parseFloat(Math.round(total * 100) / 100).toFixed(2);

		jQuery(".button-preview .ia-button-price").html(show_price + " " +total);
	}

	// update text
	var text = jQuery("[name=button-text]").val();
	if(text) {
		jQuery(".button-preview .ia-button-text").html(text);
	} else {
		jQuery(".button-preview .ia-button-text").html("One-Click Purchase");
	}
}

function position_popup() {
	jQuery(".ioc-popup").show();
	var admin_width = jQuery(".ia-admin").width();
	var popup_width = jQuery(".ioc-popup").width();
	var popup_margin = (admin_width - popup_width) / 2;

	jQuery(".ioc-popup").css("left", popup_margin + "px");
}

function load_available_apps(infusion_apps, set_app) {
	jQuery('#infusion_apps').ddslick('destroy');
	var ddData = [];

	for(var i = 0; i < infusion_apps.length; i++) {

		ddData.push({
			text: infusion_apps[i].appname + " Infusionsoft App",
	        value: infusion_apps[i].appname,
	        selected: set_app == infusion_apps[i].appname,
	        imageSrc: ioc_resources.plugin_url + "lib/images/ifsapp2.png"
		});
	}

	if(ioc_resources.infusedwoo_present == "1") {
		ddData.push({
			text: 'Connect using InfusedWoo',
	        value: 'infusedwoo',
	        selected: set_app == 'infusedwoo',
	        imageSrc: ioc_resources.plugin_url + "lib/images/infusedwoo.png"
		});
	}

	set_infusion_app(set_app);

	ddData.push({
		text: 'Add New Application...',
        value: 'add',
        selected: false,
        imageSrc: ioc_resources.plugin_url + "lib/images/add.png"
	});

	jQuery('#infusion_apps,#infusion_apps_for_smarturl').ddslick({
	    data:ddData,
	    width:300,
	    selectText: "Select Infusionsoft Application",
	    imagePosition:"right",
	    onSelected: function(selectedData){
	        if(selectedData.selectedData.value == 'add') {
	        	ioc_admin.scope.$apply( function() {
	        		ioc_admin.scope.addnewapp_popup();
	        	});
	        } else {
	        	set_infusion_app(selectedData.selectedData.value);
	        }
	    }   
	});
}

function set_infusion_app(set_app) {
	ioc_resources.infusion_app = set_app;
}

function recalc_totals() {
	var el = jQuery("table .prodprice");

	var total = 0;
	for(var i = 0; i < el.length; i++) {
		if(jQuery(el[i]).val() > 0) 
			total += parseFloat(jQuery(el[i]).val());
	}

	total = parseFloat(Math.round(total * 100) / 100).toFixed(2);

	if(total > 0) {	 
		jQuery(".totalvalue").html(total);
	} else {
		jQuery(".totalvalue").html("0.00");
	}

	payplan_preview_refresh();
	update_button_preview();
}

function enable_prod_autocomplete($el) {
	$el.focus(function() {
		if(!ioc_resources.infusion_app) {
			swal('Please select an Infusionsoft App', 'Please select an Infusionsoft App above to enable product search.' ,'warning');
			return false;
		}
	});

	$el.autocomplete({
      source: function( request, response ) {
      	var term = request.term;
      	var infusion_app = ioc_resources.infusion_app;

      	if(term.length < 3) {
      		response([{label: "Continue typing to search...", value: ""}]);
      		return true;
      	} 

      	if(!('prod_cache' in ioc_resources)) {
      		ioc_resources.prod_cache = {}; 
      	}

      	if(!(infusion_app in ioc_resources.prod_cache)) {
  			ioc_resources.prod_cache[infusion_app] = {};
  		}

      	if ( term in ioc_resources.prod_cache[infusion_app] ) {
          response( ioc_resources.prod_cache[infusion_app][ term ] );
          return true;
        }

        response([{label: "Searching...", value: ""}]);

        if(!infusion_app) {
        	swal('Please select an Infusionsoft App', 'Please select an Infusionsoft App above to enable product search.' ,'warning');
        	jQuery(this).val('');
        	response({});
        	return true;
        }

      	jQuery.getJSON(ioc_resources.ajaxurl, {action: 'ioc_productsearch', term: request.term, app:infusion_app}, function(data) {
      		ioc_resources.prod_cache[ioc_resources.infusion_app][ term ] = data;
      		response( data );
      		return true;
      	});
      },
      minLength: 1,
      select: function( event, ui ) {
        if(!ui.item){
          jQuery(this).css("color","red");
          jQuery(this).closest(".prodfield").find(".prodsearch").val("");
          jQuery(this).closest(".prodfield").find(".prodid").val("");
          jQuery(this).closest(".prodfield").find(".prodprice").val("");
        } else {
          //console.log(ui.item);
          jQuery(this).css("color","green");
          var price = parseFloat(Math.round(ui.item.price * 100) / 100).toFixed(2);
          jQuery(this).closest(".prodfield").find(".prodsearch").val(ui.item.name);

          if(!('prodvalues' in ioc_resources)) {
          	ioc_resources.prodvalues = {};
          }
          var ind = jQuery(this).index(jQuery(".prodsearch"));
          ioc_resources.prodvalues[ind] = ui.item.value;

          jQuery(this).closest(".prodfield").find(".prodid").val(ui.item.id);
          jQuery(this).closest(".prodfield").find(".prodprice").val(price);
          recalc_totals();
        }
      }
    }).keyup(function(e) {
      var code = (e.keyCode ? e.keyCode : e.which);
      if (code==13) {
          e.preventDefault();
          return false;
      }

      var ind = jQuery(this).index(jQuery(".prodsearch"));

      if(ioc_resources.prodvalues && ioc_resources.prodvalues[ind] && ioc_resources.prodvalues[ind] != jQuery(this).val()) {
        jQuery(this).closest(".prodfield").find(".prodid").val('');
        jQuery(this).css("color","red");
      }
    }).blur( function() { 
      if(!jQuery(this).closest(".prodfield").find(".prodid").val()) {
         jQuery(this).closest(".prodfield").find(".prodsearch").val("");
         jQuery(this).closest(".prodfield").find(".prodprice").val("");
         recalc_totals();
      }
    });
}

function enable_multi_autocomplete($el, endpoint, fieldname) {
	$el.focus(function() {
		if(!ioc_resources.infusion_app) {
			swal('Please select an Infusionsoft App', 'Please select an Infusionsoft App above to enable search.' ,'warning');
			return false;
		}
	});

	$el.autocomplete({
      source: function( request, response ) {
      	var term = request.term;
      	var infusion_app = ioc_resources.infusion_app;

      	if(!isInt(parseInt(term)) && term.length < 3) {
      		response([{label: "Continue typing to search...", value: ""}]);
      		return true;
      	} 

      	if(!((endpoint+'_cache') in ioc_resources)) {
      		ioc_resources[endpoint+'_cache'] = {}; 
      	}

      	if(!(infusion_app in ioc_resources[endpoint+'_cache'])) {
  			ioc_resources[endpoint+'_cache'][infusion_app] = {};
  		}

      	if ( term in ioc_resources[endpoint+'_cache'][infusion_app] ) {
          response( ioc_resources[endpoint+'_cache'][infusion_app][ term ] );
          return true;
        }

        response([{label: "Searching...", value: ""}]);

        if(!infusion_app) {
        	swal('Please select an Infusionsoft App', 'Please select an Infusionsoft App above to enable search.' ,'warning');
        	jQuery(this).val('');
        	response({});
        	return true;
        }

      	jQuery.getJSON(ioc_resources.ajaxurl, {action: 'ioc_admin_search_'+endpoint, term: request.term, app:infusion_app}, function(data) {
      		ioc_resources[endpoint+'_cache'][ioc_resources.infusion_app][ term ] = data;
      		response( data );
      		return true;
      	});
      },
      minLength: 1,
      select: function( event, ui ) {
        if(ui.item.id){
          var field = endpoint;
          if(fieldname) field = fieldname;

          jQuery(this).val('');
          allvals = jQuery('[name="'+field+'_ids[]"]');

          if(allvals.length && allvals.length > 0) {
          	for(var i = 0; i < allvals.length; i++) {
          		if(jQuery(allvals[i]).val() == ui.item.id) {
          			return false;
          		}
          	} 
          }

          var lihtml = '<li>' + ui.item.label;

          lihtml += '<input type="hidden" name="'+field+'_ids[]" value="'+ui.item.id+'" />';
          lihtml += '<input type="hidden" name="'+field+'_label[]" value="'+ui.item.label+'" />';
          lihtml += ' <i class="fa fa-times-circle del_li"></i>';
          lihtml += '</li>';
          jQuery(this).next("ul").append(lihtml);

          return false;
        }
      }
    }).keyup(function(e) {
      var code = (e.keyCode ? e.keyCode : e.which);
      if (code==13) {
          e.preventDefault();
          return false;
      }
    });
}

function isNumberKey(evt) {
  var charCode = (evt.which) ? evt.which : evt.keyCode;
  if (charCode != 46 && charCode != 37 && charCode != 39 && charCode > 31 
    && (charCode < 48 || charCode > 57))
     return false;

  return true;
}

function isInt(n){
        return Number(n)===n && n%1===0;
}