ioc_admin.load.done(function() {
	var $ctrl = ioc_admin.ctrl;
	var $scope = ioc_admin.scope;
	var $http = ioc_admin.http;

	$scope.tmtab = 'new';
	$scope.tmsaved = false;
  $scope.smartlink_id = '';
  $scope.smartlink_id_edit = '';

	enable_smartlink_filter_autocomplete(jQuery(".condition_search"));

  $scope.new_smart_url = function() {
    $scope.tmtab = 'new';
    reset_smartlink_form();
    $scope.tmsaved = false;
  };

  $scope.load_existing_smartlinks = function() {
    $scope.tmtab = 'existing';
    $scope.loading_smartlinks = true;
    $scope.smartlink_filter = '';
    $http({
        url: ajaxurl, 
        method: "GET",
        params: {action: 'ioc_get_smartlinks'}
    }).success(function(data) {
      $scope.loading_smartlinks = false;
      $scope.smartlinks = data;
    }).error(function() {
      alert('Unexpected Error: Cannot load smartlinks at this time.');
    });
  };

  $scope.load_smartlink = function(id) {
    $scope.loading_smartlinks = true;
    load_smartlink_form(id);
  }

  $scope.load_smartlink_url = function(id,title) {
    $scope.tmsaved = true;
    $scope.tmtab =  'existing-edit';
    $scope.smartlink_title = title;
    $scope.smartlink_id = id;
  }

  $scope.del_smartlink = function(id,title) {
    var user_confirm = confirm("Are you sure you want to delete Smartlink named '"+title+"'?"); 
    if(user_confirm) {
      $scope.loading_smartlinks = true;
      $http({
        url: ajaxurl, 
        method: "GET",
        params: {action: 'ioc_get_smartlinks',del: id}
      }).success(function(data) {
        $scope.loading_smartlinks = false;
        $scope.smartlinks = data;
      }).error(function() {
        alert('Unexpected Error: Cannot load smartlinks at this time.');
      });
    }
  }

  $scope.check_smartlink_filter = function(smartlink_name) {
    if($scope.smartlink_filter) {
      smartlink_name = smartlink_name.toLowerCase();
      smartlink_filter = $scope.smartlink_filter.toLowerCase();
      if(smartlink_name.indexOf(smartlink_filter.trim()) > -1) {
        return true;
      } else {
        return false;
      }
    } else {
      return true;
    }
  }

	jQuery(".tm-add").click(function() {
		tm_new_cond();
	});

	jQuery("body").on("click",".cond-remove", function() {
		jQuery(this).closest(".tm-condition").remove();

		var condcount = jQuery(".tm-condition").length;
		if(condcount > 1) {
			jQuery(".tm-condition:eq("+(condcount-1)+")").children().children(".redir").append('<div class="cond-remove">Remove</div>');
		}
	});

	jQuery("body").on("change",".smartlink-condition", function() {
		var cond = jQuery(this).val();
		var cond_ind = jQuery(this).attr("condition-id");
		var endpoint = cond.indexOf("product") > -1 ? 'products' : 'tags';

		jQuery('.condition_search[condition-id="'+cond_ind+'"]').attr("placeholder", "Enter to search " + endpoint + "...");
		jQuery(".smartlink_condition_filters_"+cond_ind).html('');
	});


  jQuery(".smartlink-save").click(function() {
      // validation:
      var errors = [];

      if(!jQuery("[name=smartlink_name]").val()) errors.push('- Smartlink name is empty.');
      if(!jQuery("[name=smartlink_app]").val()) errors.push('- Infusionsoft App is Empty');
      if(!jQuery("[name=smartlink_defaulturl]").val()) errors.push('- Default URL field is required');

      var redir_inputs = jQuery(".smartlink_redir");
      for(var i = 0; i < redir_inputs.length; i++) {
        if(!jQuery(redir_inputs[i]).val()) {
          errors.push('- Some Redirect URL fields are empty');
          break;
        }
      }

      if(errors.length > 0) {
        var alert_text = "Please check the following errors: \n\n" + errors.join("\n");
        alert(alert_text);
        return false;
      }


      jQuery(this).addClass("ia-disable2");
      jQuery(this).html('<span class="ia-button-text">Saving...</span>');
      var form_data = jQuery(".smartlink-form").serializeArray();
      
      jQuery.post(ioc_resources.ajaxurl + "?action=ioc_save_smartlink", form_data, function(data) {
          if(data.success) {
            reset_smartlink_form();
            ioc_admin.scope.$apply( function() {
              ioc_admin.scope.tmsaved = true;
              ioc_admin.scope.smartlink_id = data.id;
              ioc_admin.scope.smartlink_title = data.title;
              jQuery(".smartlink_edit_link").attr("smartlink-id", data.id);
            });
          } else {
            alert('Cannot save smartlink at this time. Please try again, otherwise contact support.');
          }

          jQuery(".smartlink-save").removeClass("ia-disable2");
          jQuery(".smartlink-save").html('<span class="ia-button-text">Save Smartlink</span>');
      }, 'json');
    });

    jQuery(".smartlink_edit_link").click(function() {
      jQuery(this).html('Please wait...');
      var smartlink_id = jQuery(this).attr('smartlink-id');
      load_smartlink_form(smartlink_id);
    });

    jQuery(".use-smartlink").click(function() {
      var smartlink_url = jQuery('.smartlink-url').html();
      jQuery("[name=ty_url]").val(smartlink_url.trim());
      jQuery(".close-animatedModal").click();
    });

    jQuery("#conditionalRedir").click(function() {
      var current_ty_uri = jQuery("[name=ty_url]").val();
      if(current_ty_uri) {
        if(current_ty_uri.indexOf('ioc_smartlink=') > -1) {
          var split = current_ty_uri.split('ioc_smartlink=');
          var smartlink_id = split[1].trim();

          ioc_admin.scope.$apply( function() {
            ioc_admin.scope.loading_smartlinks = true;
            ioc_admin.scope.tmtab = 'existing';
            ioc_admin.scope.tmsaved = false;
          });

          load_smartlink_form(smartlink_id);
        }
      }
    });
});	

function reset_smartlink_form() {
  jQuery(".smartlink_edit_link").html('Edit Smartlink');
  jQuery("[name=smartlink_id]").val('');
  jQuery(".smartlink-save").removeClass("ia-disable");
  jQuery(".smartlink-save").html('<span class="ia-button-text">Save Smartlink</span>');

  jQuery("[name=smartlink_name]").val('');
  jQuery("[name=smartlink_app]").val('');
  jQuery("[name=smartlink_defaulturl]").val('');

  jQuery(".tm-condition-extra").remove();
  jQuery(".smartlink-condition").val('some-tag');
  jQuery(".condition_search").val('');
  jQuery(".smartlink_redir").val('');
  jQuery(".smartlink_condition_filters_1").html('');

}

function load_smartlink_form(smartlink_id,tmsaved) {
  jQuery.getJSON(ioc_resources.ajaxurl, {'action': 'ioc_get_smartlink', 'id': smartlink_id}, function(data) {
      reset_smartlink_form();
      if(data.id) {
        jQuery("[name=smartlink_id]").val(data.id);
        jQuery("[name=smartlink_name]").val(ioc_stripslashes(data.title));
        jQuery("[name=smartlink_app]").val(data.app);
        jQuery("[name=smartlink_defaulturl]").val(ioc_stripslashes(data.settings.smartlink_defaulturl));

        var conditions = data.settings.smartlink_condition;

        for(cond_ind in conditions) {
          if(cond_ind > 1) {
            tm_new_cond();
          }

          jQuery('[name="smartlink_condition['+cond_ind+']"]').val(conditions[cond_ind]);
          jQuery('[name="smartlink_redir['+cond_ind+']"]').val(data.settings.smartlink_redir[cond_ind]);

          if(data.settings.smartlink_condition_filters){
            var cond_filters = data.settings.smartlink_condition_filters[cond_ind];
            if(cond_filters && cond_filters.length) {
              for(var j = 0; j < cond_filters.length; j++) {

                var lihtml = '<li>' + ioc_stripslashes(data.settings.smartlink_condition_filter_labels[cond_ind][j]);
                lihtml += '<input type="hidden" name="smartlink_condition_filters['+cond_ind+'][]" value="'+cond_filters[j]+'" />';
                lihtml += '<input type="hidden" name="smartlink_condition_filter_labels['+cond_ind+'][]" value="'+ioc_stripslashes(data.settings.smartlink_condition_filter_labels[cond_ind][j])+'" />';
                lihtml += ' <i class="fa fa-times-circle del_li"></i>';
                lihtml += '</li>';

                jQuery(".smartlink_condition_filters_" + cond_ind).append(lihtml);
              }
            }
          }
        }
      }


      ioc_admin.scope.$apply( function() {
          ioc_admin.scope.tmsaved = false;
          ioc_admin.scope.smartlink_id = smartlink_id;
          ioc_admin.scope.tmtab = 'existing-edit';
          if(tmsaved) {
            ioc_admin.scope.tmsaved = tmsaved;
          } else {
            ioc_admin.scope.tmsaved = false;
          }
        });


  }, 'json');
}

function tm_new_cond() {
  var ind = jQuery(".tm-condition").length + 1;
  jQuery(".cond-remove").remove();

  var new_cond = '<div class="tm-condition tm-condition-extra">'
  new_cond+= '    <div class="cond-label">Condition '+ind+'</div>';
  new_cond+= '    <div class="cond-box">';
  new_cond+= '      If ';
  new_cond+= '      <select class="smartlink-condition" condition-id="'+ind+'" name="smartlink_condition['+ind+']">';
  new_cond+= '        <option value="some-tag">contact has some tags </option>';
  new_cond+= '          <option value="all-tag">contact has all tags </option>';
  new_cond+= '          <option value="some-product">contact has has some products </option>';
  new_cond+= '          <option value="all-product">contact has all products </option>';
  new_cond+= '          <option value="none-tag">contact don\'t have all tags </option>';
  new_cond+= '          <option value="no-tag">contact don\'t have some tags </option>';
  new_cond+= '          <option value="none-product">contact don\'t have all products</option>';
  new_cond+= '          <option value="no-product">contact don\'t have some products</option>';
  new_cond+= '      </select>';
  new_cond+= '      <input type="text" class="condition_search" condition-id="'+ind+'" placeholder="Enter to search tag..." />';
  new_cond+= '      <ul class="smartlink_condition_filters_'+ind+' itemlist2">';
  new_cond+= '      </ul>';
  new_cond+= '      <br>';
  new_cond+= '      <div class="redir">';
  new_cond+= '      Redirect URL:';
  new_cond+= '      <input type="text" name="smartlink_redir['+ind+']" class="smartlink_redir" value="" placeholder="http://" /><br><div class="cond-remove">Remove</div>';
  new_cond+= '      </div>';
  new_cond+= '    </div>';
  new_cond+= '  </div>';

  jQuery(".tm-conditions").append(new_cond);
  enable_smartlink_filter_autocomplete(jQuery(".tm-condition:eq("+(ind-1)+")").children().children(".condition_search"));
}

function enable_smartlink_filter_autocomplete($el) {
	
	$el.focus(function() {
		var smartlink_app = jQuery("[name=smartlink_app]").val();

		if(!smartlink_app) {
			alert('Please select an Infusionsoft App First. You can add new Infusionsoft App by going to Advanced Settings');
			return false;
		}
	});

	$el.autocomplete({
      source: function( request, response ) {
      	var term = request.term;
      	var infusion_app = jQuery("[name=smartlink_app]").val();
      	var cond_ind = $el.attr("condition-id");
      	var cond = jQuery('[name="smartlink_condition['+cond_ind+']"]').val();

      	var endpoint = cond.indexOf("product") > -1 ? 'products' : 'tags';
      	


      	if(!isInt(parseInt(term)) && term.length < 3) {
      		response([{label: "Continue typing to search...", value: ""}]);
      		return true;
      	} 

      	if(!((endpoint+'_cache') in ioc_resources)) {
      		ioc_resources[endpoint+'_cache'] = {}; 
      	}

        if(!(infusion_app in ioc_resources[endpoint+'_cache'])) {
    			ioc_resources[endpoint+'_cache'][infusion_app] = {};
    		}

      	if ( term in ioc_resources[endpoint+'_cache'][infusion_app] ) {
          response( ioc_resources[endpoint+'_cache'][infusion_app][ term ] );
          return true;
        }

        response([{label: "Searching...", value: ""}]);

        if(!infusion_app) {
        	alert('Please add an Infusionsoft App first in the Advanced Settings.');
        	response({});
        	return true;
        }

      	jQuery.getJSON(ioc_resources.ajaxurl, {action: 'ioc_admin_search_'+endpoint, term: request.term, app:infusion_app}, function(data) {
      		ioc_resources[endpoint+'_cache'][infusion_app][ term ] = data;
      		response( data );
      		return true;
      	});
      },
      minLength: 1,
      select: function( event, ui ) {
        if(ui.item.id){
          jQuery(this).val('');
          var cond_ind = jQuery(this).attr("condition-id");

          allvals = jQuery('[name="smartlink_condition_filters['+cond_ind+'][]"]');

          if(allvals.length && allvals.length > 0) {
          	for(var i = 0; i < allvals.length; i++) {
          		if(jQuery(allvals[i]).val() == ui.item.id) {
          			return false;
          		}
          	} 
          }

          var lihtml = '<li>' + ui.item.label;
          lihtml += '<input type="hidden" name="smartlink_condition_filters['+cond_ind+'][]" value="'+ui.item.id+'" />';
          lihtml += '<input type="hidden" name="smartlink_condition_filter_labels['+cond_ind+'][]" value="'+ui.item.label+'" />';
          lihtml += ' <i class="fa fa-times-circle del_li"></i>';
          lihtml += '</li>';

          jQuery(".smartlink_condition_filters_"+cond_ind).append(lihtml);

          return false;
        }
      }
    }).keyup(function(e) {
      var code = (e.keyCode ? e.keyCode : e.which);
      if (code==13) {
          e.preventDefault();
          return false;
      }
    });
}

function ioc_stripslashes(str) {
    str = str.replace(/\\'/g, '\'');
    str = str.replace(/\\"/g, '"');
    str = str.replace(/\\0/g, '\0');
    str = str.replace(/\\\\/g, '\\');
    return str;
}