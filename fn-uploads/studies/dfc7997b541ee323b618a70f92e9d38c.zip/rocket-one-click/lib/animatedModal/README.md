# animatedModal.js
<p>animatedModal.js is a jQuery plugin to create a fullscreen modal with CSS3 transitions. you can use the transitions by animate.css or create yourself their transitions.</p>
<a href="http://joaopereirawd.github.io/animatedModal.js/">Documentation and demos</a>
