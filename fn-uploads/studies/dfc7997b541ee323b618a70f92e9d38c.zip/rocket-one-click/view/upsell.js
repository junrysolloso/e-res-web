var ioc_loaded_upsells 	= {};
var ioc_processing 		= false;
var ioc_lastupsell 		= false;
var ioc_lastupsell_config = {};
var ioc_last_tyurl = '';

function ioc_upsell_script_init() {
	jQuery(document).ready(function() {
		ioc_load_modallib();
		jQuery('head').append( jQuery('<link rel="stylesheet" type="text/css" />').attr('href', 'https://fonts.googleapis.com/css?family=Open+Sans:400,600,700|Pacifico|Source+Code+Pro') );	
		jQuery('head').append( jQuery('<link rel="stylesheet" type="text/css" />').attr('href', ioc_plugin_url+'lib/ia-buttons/ia-buttons.css') );
		jQuery('head').append( jQuery('<link rel="stylesheet" type="text/css" />').attr('href', ioc_plugin_url+'lib/sweetalert/sweet-alert.css') );
		jQuery('head').append( jQuery('<link rel="stylesheet" type="text/css" />').attr('href', '//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css') );

		jQuery(".ioc-upsell").each( function() {
			var upsellid = jQuery(this).attr('upsellid');
			if(upsellid == 'custom') {
				var atts = ioc_get_button_atts(jQuery(this));
				var buttonhtml = ioc_get_button_html(atts);

				jQuery(this).children('.ioc-upsell-content').html(buttonhtml);
				return;
			}

			if(ioc_loaded_upsells[upsellid]) return;
			ioc_loaded_upsells[upsellid] = {};

			jQuery.getJSON(ioc_admin_ajax, {upsellid: upsellid, action: 'ioc_get_upsell'}, function(data) {
				if(data.upsellid) {
					ioc_loaded_upsells[data.upsellid] = data; 
					var buttonhtml = ioc_get_button_html(data);

					jQuery(".ioc-upsell[upsellid="+data.upsellid+"] .ioc-upsell-content").html(buttonhtml);
				}
			});
		});

		jQuery(".ioc-upsell").click(function() {
			$upsell_el = jQuery(this);
			var upsellid = $upsell_el.attr('upsellid');
			var urlvars = ioc_getUrlVars();
			var upsell_config = {};

			if(upsellid == 'custom') {
				upsell_config = ioc_get_button_atts($upsell_el);
				urlvars.custom_upsell = upsell_config;

				if(upsell_config['processing-msg']) upsell_config['processing_msg'] = upsell_config['processing-msg'];
			} else {
				upsell_config = ioc_loaded_upsells[upsellid];
			}

			if(upsell_config['conf_dialog'] == 'true') {
		     	swal({   
		     		title: "Please Confirm",   
		     		text: upsell_config['conf_dialog_msg'],   
		     		type: "warning",   
		     		showCancelButton: true,   
		     		confirmButtonColor: "#76D21C",   
		     		confirmButtonText: "Continue",   
		     		closeOnConfirm: true
		     	}, function() {
		     		ioc_submit_upsell($upsell_el);
		     	});

			} else {
				ioc_submit_upsell(jQuery(this));
			}

			return false;
		});

		jQuery(".ioc-nothanks").click(function() {
			ioc_nothanks(jQuery(this).attr("upsellid"));
			return false;
		});

		jQuery(".ioc-nothanks-custom").click(function(e) {
			e.preventDefault();
			var ty_pass = "";

			if(window.location.href.indexOf('?') != -1) {
				var ty_pass = window.location.href.slice(window.location.href.indexOf('?') + 1);
			}
			ioc_last_tyurl = jQuery(this).attr('href');
			var decline_ids = jQuery(this).attr('actions').split(",");
			var decline_tags = jQuery(this).attr('tags').split(",");

			if(decline_ids || decline_tags) {
				var urlvars = ioc_getUrlVars();
				urlvars['actions'] = decline_ids;
				urlvars['tags'] = decline_tags;
				urlvars['infusion_app'] = jQuery(this).attr('infusion_app');

				jQuery.post(ioc_admin_ajax + '?action=ioc_decline_upsell', urlvars, function(data) {
					if(ioc_last_tyurl.indexOf("?") > -1) {
						location.href = ioc_last_tyurl + "&" + ty_pass;
					} else {
						location.href = ioc_last_tyurl + "?" + ty_pass;
					}
				});
			} else {
				if(ioc_last_tyurl.indexOf("?") > -1) {
					location.href = ioc_last_tyurl + "&" + ty_pass;
				} else {
					location.href = ioc_last_tyurl + "?" + ty_pass;
				}
			}
		});

		jQuery("body").on("click", ".ioc-cc-new", function() {
			var upsellsettings = ioc_lastupsell_config['cc_panel_options'];
			ioc_show_cc_panel(upsellsettings);
		});

		jQuery("body").on("click", ".ioc-cc-save", function() {
			ioc_validateCC();
		});

		jQuery("body").on("keyup","[name=ccnumber]", function() {
			var cctype = ioc_checkCCType(jQuery(this).val());

			jQuery(".ioc-cc-icons").css("opacity", 0.5);

			switch(cctype) {
				case 'MasterCard':
					jQuery(".ioc-cc-icons-mc").css("opacity", 1);
					break;
				case 'Visa':
					jQuery(".ioc-cc-icons-visa").css("opacity", 1);
					break;
				case 'Discover':
					jQuery(".ioc-cc-icons-disc").css("opacity", 1);
					break;
				case 'American Express':
					jQuery(".ioc-cc-icons-amex").css("opacity", 1);
					break;
				default:
					jQuery(".ioc-cc-icons").css("opacity", 1);
					break;
			}

		});
 	});
}

function ioc_get_button_html(data) {
	var button_text = data['button-text'] !== '' ? data['button-text'] : "One-Click Purchase";
	var type = data.product_type;
	var advanced_embed = data['advanced-embed'];
	var total = 0;

	if(advanced_embed == 'link') {
		buttonhtml = data['custom-text'] ? data['custom-text'] : 'One-Click Purchase';
	} else if(advanced_embed == 'image') {
		buttonhtml = '<img src="'+data['upload_image']+'" class="ioc-upsell-custom-img" />';
	} else {
		if(data.subscription) {
			total = parseFloat(data.sub_price);
		} else if(data.prices) {
			total = 0;
			var prods = data.items.split(",");
			var prices = data.prices.split(",");
			for(var i=0;i<prices.length;i++) {
				var quant = 1;
				if(prods[i].indexOf("p") > -1) {
					var qp = prods[i].split("p");
					if(qp[0] != '')  quant = parseInt(qp[0]);
				}				

				total += parseFloat(quant*parseFloat(prices[i]));
			}

		} else {
			var total = parseFloat(data.single_prodprice);
			if(type == 'single-prod' || type == 'bundled-prod') {		
				if(type == 'bundled-prod') {
					var total = 0;
					for(var i = 0; i < data.prodprice.length; i++) {
						total += parseFloat(data.prodprice[i]);
					}
				} else {
					total = parseFloat(data.single_prodprice);
				}
				total = data.initpay ? parseFloat(data.initpay) : total;
			} else if(type == 'subscription') {
				var signupfee = data.signupfee;
				signupfee = signupfee ? parseFloat(signupfee) : 0;

				var trialdays = data.freetrial;
				trialdays = trialdays ? parseInt(trialdays) : 0;

				if(trialdays > 0) total = signupfee;
				else total = total + signupfee;
			}
		}

		// Custom Fee
		if(data['customline']) {
			var cl = data['customline'];
			for(var c = 0; c < cl.length; c++) {
				var linetype = cl[c];
				if(linetype == 'Discount') {
					total -= parseFloat(data['customlinefee'][c]);
				} else if(linetype != '') {
					total += parseFloat(data['customlinefee'][c]);
				}
			}
		}

		var total = parseFloat(Math.round(total * 100) / 100).toFixed(2);


		var buttonhtml = '<div class="ia-button ia-'+data['button-theme']+' ia-'+data['button-color']+' ia-'+data['button-size']+'">';
		buttonhtml += '<span class="ia-button-icon"><i class="fa fa-'+data['button-icon']+'"></i></span>';
		buttonhtml += '<span class="ia-button-text">'+button_text+'</span>';

		if(data['button-show-price'] != 'no') {
			buttonhtml += '<span class="ia-button-price">'+data['button-show-price']+' '+total+'</span>';
		}
		buttonhtml += '</div>';
	}

	return buttonhtml;
}

function ioc_get_button_atts($button) {
	var params = $button.parent('.ioc-custom-upsell').serializeArray();
	var atts = {};
	jQuery.each(params, function() {
        if (atts[this.name] !== undefined) {
            if (!atts[this.name].push) {
                atts[ioc_replaceAll("_","-",this.name)] = [atts[this.name]];
            }
            atts[ioc_replaceAll("_","-",this.name)].push(this.value || '');
        } else {
            atts[ioc_replaceAll("_","-",this.name)] = this.value || '';
        }
    });

    return atts;
}

function ioc_replaceAll(find, replace, str) {
  return str.replace(new RegExp(find, 'g'), replace);
}

function ioc_submit_upsell($upsell_el, new_card) {
	if(!ioc_processing) {
		ioc_disable_upsell_buttons();

		var urlvars = ioc_getUrlVars();
		var upsellid = $upsell_el.attr('upsellid');
		urlvars.upsellid = upsellid;
		ioc_lastupsell= $upsell_el;

		if(upsellid == 'custom') {
			var upsell_config = ioc_get_button_atts($upsell_el);
			urlvars.custom_upsell = upsell_config;

			if(upsell_config['processing-msg']) upsell_config['processing_msg'] = upsell_config['processing-msg'];
		} else {
			var upsell_config = ioc_loaded_upsells[urlvars.upsellid];
		}

		ioc_lastupsell_config = upsell_config;

		if(new_card) {
			ioc_loading_cc(upsell_config['processing_msg']);
			urlvars.newcard = true;
			for(k in new_card) {
				urlvars[k] = new_card[k]; 
			}
		} else {
			urlvars.newcard = false;
		}

		if(upsell_config['show_processing'] == 'true') {
			ioc_loading_cc(upsell_config['processing_msg']);
		}

		jQuery.post(ioc_admin_ajax + '?action=ioc_submit_upsell', urlvars, function(data) {
			if(!data.success) {
				ioc_processing = false;
				jQuery(".ioc-upsell").css("opacity", "1");
				jQuery(".ioc-upsell").css("cursor", "pointer");

				if(data.cc_panel_options) {
					ioc_lastupsell_config.cc_panel_options = data.cc_panel_options;
				}

				ioc_show_error(data.errormsg, data.errorcode);
			} else {
				ioc_success_redir(data.redir);
			}
		},'json');

		return false;
	}
}

function ioc_nothanks(upsellid) {
	if(ioc_loaded_upsells[upsellid].nothanks_url) {
		var ty_pass = "";
		if(window.location.href.indexOf('?') != -1) {
			var ty_pass = window.location.href.slice(window.location.href.indexOf('?') + 1);
		}
		ioc_last_tyurl = ioc_loaded_upsells[upsellid].nothanks_url;

		if(ioc_loaded_upsells[upsellid].decline_ids || ioc_loaded_upsells[upsellid].declinetag_ids) {
			var urlvars = ioc_getUrlVars();
			urlvars['actions'] = ioc_loaded_upsells[upsellid].decline_ids;
			urlvars['tags'] = ioc_loaded_upsells[upsellid].declinetag_ids;
			urlvars.upsellid = upsellid;

			jQuery.post(ioc_admin_ajax + '?action=ioc_decline_upsell', urlvars, function(data) {
				if(ioc_last_tyurl.indexOf("?") > -1) {
					location.href = ioc_last_tyurl + "&" + ty_pass;
				} else {
					location.href = ioc_last_tyurl + "?" + ty_pass;
				}
			},'json');
		} else {
			if(ioc_last_tyurl.indexOf("?") > -1) {
				location.href = ioc_last_tyurl + "&" + ty_pass;
			} else {
				location.href = ioc_last_tyurl + "?" + ty_pass;
			}
		}
	}
}

function ioc_disable_upsell_buttons() {
	var butcount = 0;
	jQuery(".ioc-upsell").each(function() {
		butcount++;

		jQuery(".ioc-upsell").css("cursor", "wait");
		jQuery(".ioc-upsell").css("opacity", "0.5");
		ioc_processing = true;
	});
}


function ioc_getUrlVars() {
    var vars = {};
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars[hash[0]] = hash[1];
    }
    return vars;
}

function ioc_load_modallib() {
	;(function($){
	    jQuery.ioc_pgwModal = function(obj) {

	        var pgwModal = {};
	        var defaults = {
	            mainClassName : 'pgwModal',
	            backdropClassName : 'pgwModalBackdrop',
	            maxWidth : 500,
	            titleBar : true,
	            closable : true,
	            closeOnEscape : true,
	            closeOnBackgroundClick : true,
	            closeContent : '<span class="pm-icon"></span>',
	            loadingContent : 'Loading in progress...',
	            errorContent : 'An error has occured. Please try again in a few moments.'
	        };

	        if (typeof window.pgwModalObject != 'undefined') {
	            pgwModal = window.pgwModalObject;
	        }

	        // Merge the defaults and the user's config
	        if ((typeof obj == 'object') && (! obj.pushContent)) {
	            if (! obj.url && ! obj.target && ! obj.content) {
	                throw new Error('PgwModal - There is no content to display, please provide a config parameter : "url", "target" or "content"');
	            }

	            pgwModal.config = {};
	            pgwModal.config = jQuery.extend({}, defaults, obj);
	            window.pgwModalObject = pgwModal;
	        }

	        // Create modal container
	        var create = function() {
	            // The backdrop must be outside the main container, otherwise Chrome displays the scrollbar of the modal below
	            var appendBody = '<div id="pgwModalBackdrop"></div>'
	                + '<div id="pgwModal">'
	                + '<div class="pm-container">'
	                + '<div class="pm-body">'
	                + '<span class="pm-close"></span>'
	                + '<div class="pm-title"></div>'
	                + '<div class="pm-content"></div>'
	                + '</div>'
	                + '</div>'
	                + '</div>';

	            jQuery('body').append(appendBody);
	            jQuery(document).trigger('PgwModal::Create');
	            return true;
	        };

	        // Reset modal container
	        var reset = function() {
	            jQuery('#pgwModal .pm-title, #pgwModal .pm-content').html('');
	            jQuery('#pgwModal .pm-close').html('').unbind('click');
	            return true;
	        };

	        // Angular compilation
	        var angularCompilation = function() {
	            angular.element('body').injector().invoke(function($compile) {
	                var scope = angular.element(jQuery('#pgwModal .pm-content')).scope();
	                $compile(jQuery('#pgwModal .pm-content'))(scope);
	                scope.$digest();
	            });
	            return true;
	        };

	        // Push content into the modal
	        var pushContent = function(content) {
	            jQuery('#pgwModal .pm-content').html(content);

	            // Angular
	            if (pgwModal.config.angular) {
	                angularCompilation();
	            }

	            reposition();

	            jQuery(document).trigger('PgwModal::PushContent');
	            return true;
	        };

	        // Repositions the modal
	        var reposition = function() {
	            // Elements must be visible before height calculation
	            jQuery('#pgwModal, #pgwModalBackdrop').show();

	            var windowHeight = jQuery(window).height();
	            var modalHeight = jQuery('#pgwModal .pm-body').height();
	            var marginTop = Math.round((windowHeight - modalHeight) / 3);
	            if (marginTop <= 0) {
	                marginTop = 0;
	            }

	            jQuery('#pgwModal .pm-body').css('margin-top', marginTop);
	            return true;
	        };

	        // Returns the modal data
	        var getData = function() {
	            return pgwModal.config.modalData;
	        };

	        // Returns the scrollbar width
	        var getScrollbarWidth = function() {
	            var container = jQuery('<div style="width:50px;height:50px;overflow:auto"><div></div></div>').appendTo('body');
	            var child = container.children();

	            // Check for Zepto
	            if (typeof child.innerWidth != 'function') {
	                return 0;
	            }

	            var width = child.innerWidth() - child.height(90).innerWidth();
	            container.remove();

	            return width;
	        };

	        // Returns the modal status
	        var isOpen = function() {
	            return jQuery('body').hasClass('pgwModalOpen');
	        };

	        // Close the modal
	        var close = function() {
	            jQuery('#pgwModal, #pgwModalBackdrop').removeClass().hide();
	            jQuery('body').css('padding-right', '').removeClass('pgwModalOpen');

	            // Reset modal
	            reset();

	            // Disable events
	            jQuery(window).unbind('resize.PgwModal');
	            jQuery(document).unbind('keyup.PgwModal');
	            jQuery('#pgwModal').unbind('click.PgwModalBackdrop');

	            try {
	                delete window.pgwModalObject; 
	            } catch(e) {
	                window['pgwModalObject'] = undefined; 
	            }

	            jQuery(document).trigger('PgwModal::Close');
	            return true;
	        };

	        // Open the modal
	        var open = function() {
	            if (jQuery('#pgwModal').length == 0) {
	                create();
	            } else {
	                reset();
	            }

	            // Set CSS classes
	            jQuery('#pgwModal').removeClass().addClass(pgwModal.config.mainClassName);
	            jQuery('#pgwModalBackdrop').removeClass().addClass(pgwModal.config.backdropClassName);

	            // Close button
	            if (! pgwModal.config.closable) {
	                jQuery('#pgwModal .pm-close').html('').unbind('click').hide();
	            } else {
	                jQuery('#pgwModal .pm-close').html(pgwModal.config.closeContent).click(function() {
	                    close();
	                }).show();
	            }

	            // Title bar
	            if (! pgwModal.config.titleBar) {
	                jQuery('#pgwModal .pm-title').hide();
	            } else {
	                jQuery('#pgwModal .pm-title').show();
	            }

	            if (pgwModal.config.title) {
	                jQuery('#pgwModal .pm-title').text(pgwModal.config.title);
	            }

	            if (pgwModal.config.maxWidth) {
	                jQuery('#pgwModal .pm-body').css('max-width', pgwModal.config.maxWidth);
	            }

	            // Content loaded by Ajax
	            if (pgwModal.config.url) {
	                if (pgwModal.config.loadingContent) {
	                    jQuery('#pgwModal .pm-content').html(pgwModal.config.loadingContent);
	                }

	                var ajaxOptions = {
	                    'url' : obj.url,
	                    'success' : function(data) {
	                        pushContent(data);
	                    },
	                    'error' : function() {
	                        jQuery('#pgwModal .pm-content').html(pgwModal.config.errorContent);
	                    }
	                };

	                if (pgwModal.config.ajaxOptions) {
	                    ajaxOptions = jQuery.extend({}, ajaxOptions, pgwModal.config.ajaxOptions);
	                }

	                jQuery.ajax(ajaxOptions);
	                
	            // Content loaded by a html element
	            } else if (pgwModal.config.target) {
	                pushContent(jQuery(pgwModal.config.target).html());

	            // Content loaded by a html object
	            } else if (pgwModal.config.content) {
	                pushContent(pgwModal.config.content);
	            }

	            // Close on escape
	            if (pgwModal.config.closeOnEscape && pgwModal.config.closable) {
	                jQuery(document).bind('keyup.PgwModal', function(e) {
	                    if (e.keyCode == 27) {
	                        close();
	                    }
	                });
	            }

	            // Close on background click
	            if (pgwModal.config.closeOnBackgroundClick && pgwModal.config.closable) {
	                jQuery('#pgwModal').bind('click.PgwModalBackdrop', function(e) {
	                    var targetClass = jQuery(e.target).hasClass('pm-container');
	                    var targetId = jQuery(e.target).attr('id');
	                    if (targetClass || targetId == 'pgwModal') {
	                        close();
	                    }
	                });
	            }

	            // Add CSS class on the body tag
	            jQuery('body').addClass('pgwModalOpen');

	            var currentScrollbarWidth = getScrollbarWidth();
	            if (currentScrollbarWidth > 0) {
	                jQuery('body').css('padding-right', currentScrollbarWidth);
	            }

	            // Resize event for reposition
	            jQuery(window).bind('resize.PgwModal', function() {
	                reposition();
	            });

	            jQuery(document).trigger('PgwModal::Open');
	            return true;
	        };

	        // Choose the action
	        if ((typeof obj == 'string') && (obj == 'close')) {
	            return close();

	        } else if ((typeof obj == 'string') && (obj == 'reposition')) {
	            return reposition();

	        } else if ((typeof obj == 'string') && (obj == 'getData')) {
	            return getData();

	        } else if ((typeof obj == 'string') && (obj == 'isOpen')) {
	            return isOpen();

	        } else if ((typeof obj == 'object') && (obj.pushContent)) {
	            return pushContent(obj.pushContent);

	        } else if (typeof obj == 'object') {
	            return open();
	        }
	    }
	})(window.Zepto || window.jQuery);
}

function ioc_success_redir(redir) {
	if(redir) {
		var ty_pass = "";
		if(window.location.href.indexOf('?') != -1) {
			var ty_pass = window.location.href.slice(window.location.href.indexOf('?') + 1);
		}
		
		var ty_url = redir;
		if(ty_url.indexOf("?") > -1) {
			location.href = ty_url + "&" + ty_pass;
		} else {
			location.href = ty_url + "?" + ty_pass;
		}
		
	}
}

function ioc_loading_cc(modal_title) {
	var loadhtml = '<center><img src="'+ioc_plugin_url+'lib/images/secure_cc.png" class="ioc-loadhtml" />';
	loadhtml += '<br><img src="'+ioc_plugin_url+'lib/images/ajax-loader-h.gif" />';
	loadhtml += '</center>';

	jQuery.ioc_pgwModal({
    	content: loadhtml,
    	closable: false,
    	title: modal_title
	});
}

function ioc_show_error(errormsg, errorcode) {
	var errorhtml = '<center><img src="'+ioc_plugin_url+'lib/images/error.png" width=100 height=100 class="ioc-loadhtml" /><br><br>';
	errorhtml += errormsg;
	
	var upsellsettings = ioc_lastupsell_config['cc_panel_options'];

	if(ioc_lastupsell_config['allow-new-cc']) {
		ioc_lastupsell_config['allow_new_cc'] = ioc_lastupsell_config['allow-new-cc'];
	}

	if(ioc_lastupsell_config['allow_new_cc'] == 'true' && errorcode == 'chargefailed') {
		errorhtml += '<center class="ioc-cc-use-new"><div class="ioc-cc-new ia-button ia-flat ia-green">'+upsellsettings.usenewbutton+'</div></center>';
	}

	if(ioc_lastupsell_config['allow_new_cc'] == 'true' && errorcode == 'nocreditcard') {
		errorhtml += '<center class="ioc-cc-use-new"><div class="ioc-cc-new ia-button ia-flat ia-green">'+upsellsettings.addbutton+'</div></center>';
	}

	errorhtml += '</br></center>';



	jQuery.ioc_pgwModal({
    	content: errorhtml,
    	closable: true,
    	title: 'Transaction Failed'
	});
}

function ioc_show_cc_panel(ccpanel_fields) {
	jQuery(".ioc-cc-panel input").val('');
	if(!ccpanel_fields) {
		ccpanel_fields = {
			paneltitle: 'Use a new credit card',
			ccnumber: 'Credit Card Number',
			expires: 'Expiration',
			cvv: 'CVV',
			zip: 'Postal Code',
			save: 'Use this Credit Card',
			accepted: ['Visa','MasterCard','American Express','Discover'],
			addbutton: 'Add a New Credit Card',
			usenewbutton: 'Use Another Card Instead'
		};
	}

	var modal_content = '<div class="ioc-cc-panel">';
	modal_content += '<img src="'+ioc_plugin_url+'lib/images/secure_cc.png" class="ioc-secure-cc"/>';

	modal_content += '<div class="ioc-cc-fieldset">';
	modal_content += '<div class="ioc-cc-icons-wrap">';
	if(jQuery.inArray("Visa", ccpanel_fields['accepted'])!==-1) 
		modal_content += '<img src="'+ioc_plugin_url+'lib/images/cc-icons-visa.png" class="ioc-cc-icons ioc-cc-icons-visa" />';
	if(jQuery.inArray("MasterCard", ccpanel_fields['accepted'])!==-1) 
		modal_content += '<img src="'+ioc_plugin_url+'lib/images/cc-icons-mc.png" class="ioc-cc-icons ioc-cc-icons-mc" />';
	if(jQuery.inArray("American Express", ccpanel_fields['accepted'])!==-1) 
		modal_content += '<img src="'+ioc_plugin_url+'lib/images/cc-icons-amex.png" class="ioc-cc-icons ioc-cc-icons-amex" />';
	if(jQuery.inArray("Discover", ccpanel_fields['accepted'])!==-1) 
		modal_content += '<img src="'+ioc_plugin_url+'lib/images/cc-icons-disc.png" class="ioc-cc-icons ioc-cc-icons-disc" />';
	modal_content += '</div>';
	modal_content += '<div class="ioc-cc-field ioc-cc-field-ccnumber"><label>'+ccpanel_fields.ccnumber+'</label><br><input type="text" class="cc-long" name="ccnumber" />';

	modal_content += '</div>';
	modal_content += '<div class="ioc-cc-field"><label>'+ccpanel_fields.expires+'</label><br><input type="text" class="cc-shorter" name="expires_month" placeholder="01" />';
	modal_content += '<span class="ioc-separator">/</span><input type="text" class="cc-shorter" name="expires_year" placeholder="'+(new Date().getFullYear() + 3)+'" /></div>';
	modal_content += '<div class="ioc-cc-field"><label>'+ccpanel_fields.cvv+'</label><br><input type="text" name="cvv" class="cc-short" placeholder="" /></div>';
	modal_content += '<div class="ioc-cc-field"><label>'+ccpanel_fields.zip+'</label><br><input type="text" name="zip" class="cc-short" placeholder="" /></div>';
	modal_content += '</div>';
	modal_content += '<center class="ioc-cc-save-wrap"><div class="ioc-cc-save ia-button ia-flat ia-green">'+ccpanel_fields.save+'</div></center>';
	modal_content += '<div class="ioc-cc-notices" style="display:none;">Invalid Credit Card Number</div>';
	modal_content += '</div>';

	jQuery.ioc_pgwModal({
    	content: modal_content,
    	closable: true,
    	title: ccpanel_fields.paneltitle
	});

}

function ioc_validateCC() {
	var ccnumber = jQuery('.ioc-cc-panel input[name="ccnumber"]').val();
	var expires_month = jQuery('.ioc-cc-panel input[name="expires_month"]').val();
	var expires_year = jQuery('.ioc-cc-panel input[name="expires_year"]').val();
	var cvv = jQuery('.ioc-cc-panel input[name="cvv"]').val();
	var zip = jQuery('.ioc-cc-panel input[name="zip"]').val();
	var cctype = ioc_checkCCType(ccnumber);

	var errors = [];
	var current_year = new Date().getFullYear();
	var current_month = new Date().getMonth() + 1;
	var ccpanel_fields = ioc_lastupsell_config['cc_panel_options'];

	if(ccnumber == "") errors.push('Credit Card Number is Empty');
	else if(!ioc_luhnChk(ccnumber)) errors.push('Credit Card Number Entered is Invalid');
	else if(jQuery.inArray(cctype, ccpanel_fields['accepted'])==-1){
		errors.push('We currently don\'t accept ' + cctype + ' Credit Cards');
	}
	
	if(expires_month == "") errors.push('Card Expiration Month is Empty');  
	else {
		var month_int = parseInt(expires_month);
		if(!(month_int > 0 && month_int <= 12)) errors.push('Expiration Month should be within 01 to 12'); 
	}

	if(expires_year == "") errors.push('Card Expiration Year is Empty');  
	else {
		var year_int = parseInt(expires_year);
		if(year_int < current_year) errors.push('Card Already Expired'); 
	}

	
	if( current_year == year_int && month_int < current_month ) errors.push('Card Already Expired'); 

	if(cvv == "") errors.push('Card Security Code is Empty');  
	else {
		if(cvv.length != 4 && cctype == 'American Express') errors.push('Card Security Code is Invalid'); 
		else if(cvv.length != 3 && cctype != 'American Express') errors.push('Card Security Code is Invalid'); 
	}

	if(zip == "") errors.push('Postal Code is Empty'); 

	if(errors.length > 0) {
		jQuery(".ioc-cc-notices").html(errors[0]);
		jQuery(".ioc-cc-notices").show();
	} else {
		var new_card = {
			ccnumber: ccnumber,
			expires_month: expires_month,
			expires_year: expires_year,
			cvv: cvv,
			zip: zip,
			cctype: cctype
		};
		ioc_submit_upsell(ioc_lastupsell, new_card);		
	}
}

function ioc_checkCCType(ccnumber) {
	if(ccnumber) {
		var firstnum = ccnumber.charAt(0);
		var cctype = false;

		switch(firstnum) {
			case '3': cctype = 'American Express'; break;
			case '4': cctype = 'Visa'; break;
			case '5': cctype = 'MasterCard'; break;
			case '6': cctype = 'Discover'; break;
		}

		return cctype;
	} else {
		return false;
	}
}

var ioc_luhnChk = (function (arr) {
    return function (ccNum) {
        var 
            len = ccNum.length,
            bit = 1,
            sum = 0,
            val;
 
        while (len) {
            val = parseInt(ccNum.charAt(--len), 10);
            sum += (bit ^= 1) ? arr[val] : val;
        }
 
        return sum && sum % 10 === 0;
    };
}([0, 2, 4, 6, 8, 1, 3, 5, 7, 9]));




if (typeof jQuery == 'undefined') {
	if (typeof $ == 'function') {
		// warning, global var
		thisPageUsingOtherJSLibrary = true;
	}
	
	function ioc_getScript(url, success) {
		var script     = document.createElement('script');
		     script.src = url;

		var head = document.getElementsByTagName('head')[0],
		done = false;
		
		// Attach handlers for all browsers
		script.onload = script.onreadystatechange = function() {
		
			if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
				done = true;
				// callback function provided as param
				success();
				
				script.onload = script.onreadystatechange = null;
				head.removeChild(script);
			};
		};
		
		head.appendChild(script);
	};
	
	ioc_getScript('https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js', function() {
		if (typeof jQuery=='undefined') {
			console.log('Jquery Include Error.. Please check for other script issues in this page');
		} else {
			ioc_upsell_script_init();
		}
	});
} else {
	ioc_upsell_script_init();
};

// minified swal
	!function(e,t){function n(t){var n=y(),o=n.querySelector("h2"),r=n.querySelector("p"),a=n.querySelector("button.cancel"),c=n.querySelector("button.confirm");if(o.innerHTML=w(t.title).split("\n").join("<br>"),r.innerHTML=w(t.text||"").split("\n").join("<br>"),t.text&&S(r),C(n.querySelectorAll(".icon")),t.type){for(var l=!1,s=0;s<d.length;s++)if(t.type===d[s]){l=!0;break}if(!l)return e.console.error("Unknown alert type: "+t.type),!1;var u=n.querySelector(".icon."+t.type);switch(S(u),t.type){case"success":v(u,"animate"),v(u.querySelector(".tip"),"animateSuccessTip"),v(u.querySelector(".long"),"animateSuccessLong");break;case"error":v(u,"animateErrorIcon"),v(u.querySelector(".x-mark"),"animateXMark");break;case"warning":v(u,"pulseWarning"),v(u.querySelector(".body"),"pulseWarningIns"),v(u.querySelector(".dot"),"pulseWarningIns")}}if(t.imageUrl){var f=n.querySelector(".icon.custom");f.style.backgroundImage="url("+t.imageUrl+")",S(f);var m=80,p=80;if(t.imageSize){var g=t.imageSize.split("x")[0],b=t.imageSize.split("x")[1];g&&b?(m=g,p=b,f.css({width:g+"px",height:b+"px"})):e.console.error("Parameter imageSize expects value with format WIDTHxHEIGHT, got "+t.imageSize)}f.setAttribute("style",f.getAttribute("style")+"width:"+m+"px; height:"+p+"px")}n.setAttribute("data-has-cancel-button",t.showCancelButton),t.showCancelButton?a.style.display="inline-block":C(a),t.cancelButtonText&&(a.innerHTML=w(t.cancelButtonText)),t.confirmButtonText&&(c.innerHTML=w(t.confirmButtonText)),c.style.backgroundColor=t.confirmButtonColor,i(c,t.confirmButtonColor),n.setAttribute("data-allow-ouside-click",t.allowOutsideClick);var h=t.doneFunction?!0:!1;n.setAttribute("data-has-done-function",h),n.setAttribute("data-timer",t.timer)}function o(e,t){e=String(e).replace(/[^0-9a-f]/gi,""),e.length<6&&(e=e[0]+e[0]+e[1]+e[1]+e[2]+e[2]),t=t||0;var n="#",o,r;for(r=0;3>r;r++)o=parseInt(e.substr(2*r,2),16),o=Math.round(Math.min(Math.max(0,o+o*t),255)).toString(16),n+=("00"+o).substr(o.length);return n}function r(e,t){for(var n in t)t.hasOwnProperty(n)&&(e[n]=t[n]);return e}function a(e){var t=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(e);return t?parseInt(t[1],16)+", "+parseInt(t[2],16)+", "+parseInt(t[3],16):null}function i(e,t){var n=a(t);e.style.boxShadow="0 0 2px rgba("+n+", 0.8), inset 0 0 0 1px rgba(0, 0, 0, 0.05)"}function c(){var e=y();T(p(),10),S(e),v(e,"showSweetAlert"),b(e,"hideSweetAlert"),I=t.activeElement;var n=e.querySelector("button.confirm");n.focus(),setTimeout(function(){v(e,"visible")},500);var o=e.getAttribute("data-timer");"null"!==o&&""!==o&&(e.timeout=setTimeout(function(){l()},o))}function l(){var n=y();E(p(),5),E(n,5),b(n,"showSweetAlert"),v(n,"hideSweetAlert"),b(n,"visible");var o=n.querySelector(".icon.success");b(o,"animate"),b(o.querySelector(".tip"),"animateSuccessTip"),b(o.querySelector(".long"),"animateSuccessLong");var r=n.querySelector(".icon.error");b(r,"animateErrorIcon"),b(r.querySelector(".x-mark"),"animateXMark");var a=n.querySelector(".icon.warning");b(a,"pulseWarning"),b(a.querySelector(".body"),"pulseWarningIns"),b(a.querySelector(".dot"),"pulseWarningIns"),e.onkeydown=M,t.onclick=A,I&&I.focus(),z=void 0,clearTimeout(n.timeout)}function s(){var e=y();e.style.marginTop=B(y())}var u=".sweet-alert",f=".sweet-overlay",d=["error","warning","info","success"],m={title:"",text:"",type:null,allowOutsideClick:!1,showCancelButton:!1,closeOnConfirm:!0,closeOnCancel:!0,confirmButtonText:"OK",confirmButtonColor:"#AEDEF4",cancelButtonText:"Cancel",imageUrl:null,imageSize:null,timer:null},y=function(){return t.querySelector(u)},p=function(){return t.querySelector(f)},g=function(e,t){return new RegExp(" "+t+" ").test(" "+e.className+" ")},v=function(e,t){g(e,t)||(e.className+=" "+t)},b=function(e,t){var n=" "+e.className.replace(/[\t\r\n]/g," ")+" ";if(g(e,t)){for(;n.indexOf(" "+t+" ")>=0;)n=n.replace(" "+t+" "," ");e.className=n.replace(/^\s+|\s+$/g,"")}},w=function(e){var n=t.createElement("div");return n.appendChild(t.createTextNode(e)),n.innerHTML},h=function(e){e.style.opacity="",e.style.display="block"},S=function(e){if(e&&!e.length)return h(e);for(var t=0;t<e.length;++t)h(e[t])},x=function(e){e.style.opacity="",e.style.display="none"},C=function(e){if(e&&!e.length)return x(e);for(var t=0;t<e.length;++t)x(e[t])},k=function(e,t){for(var n=t.parentNode;null!==n;){if(n===e)return!0;n=n.parentNode}return!1},B=function(e){e.style.left="-9999px",e.style.display="block";var t=e.clientHeight,n;return n="undefined"!=typeof getComputedStyle?parseInt(getComputedStyle(e).getPropertyValue("padding"),10):parseInt(e.currentStyle.padding),e.style.left="",e.style.display="none","-"+parseInt(t/2+n)+"px"},T=function(e,t){if(+e.style.opacity<1){t=t||16,e.style.opacity=0,e.style.display="block";var n=+new Date,o=function(){e.style.opacity=+e.style.opacity+(new Date-n)/100,n=+new Date,+e.style.opacity<1&&setTimeout(o,t)};o()}e.style.display="block"},E=function(e,t){t=t||16,e.style.opacity=1;var n=+new Date,o=function(){e.style.opacity=+e.style.opacity-(new Date-n)/100,n=+new Date,+e.style.opacity>0?setTimeout(o,t):e.style.display="none"};o()},q=function(n){if(MouseEvent){var o=new MouseEvent("click",{view:e,bubbles:!1,cancelable:!0});n.dispatchEvent(o)}else if(t.createEvent){var r=t.createEvent("MouseEvents");r.initEvent("click",!1,!1),n.dispatchEvent(r)}else t.createEventObject?n.fireEvent("onclick"):"function"==typeof n.onclick&&n.onclick()},O=function(t){"function"==typeof t.stopPropagation?(t.stopPropagation(),t.preventDefault()):e.event&&e.event.hasOwnProperty("cancelBubble")&&(e.event.cancelBubble=!0)},I,A,M,z;e.sweetAlertInitialize=function(){var e='<div class="sweet-overlay" tabIndex="-1"></div><div class="sweet-alert" tabIndex="-1"><div class="icon error"><span class="x-mark"><span class="line left"></span><span class="line right"></span></span></div><div class="icon warning"> <span class="body"></span> <span class="dot"></span> </div> <div class="icon info"></div> <div class="icon success"> <span class="line tip"></span> <span class="line long"></span> <div class="placeholder"></div> <div class="fix"></div> </div> <div class="icon custom"></div> <h2>Title</h2><p>Text</p><button class="cancel" tabIndex="2">Cancel</button><button class="confirm" tabIndex="1">OK</button></div>',n=t.createElement("div");n.innerHTML=e,t.body.appendChild(n)},e.sweetAlert=e.swal=function(){function a(t){var n=t||e.event,o=n.keyCode||n.which;if(-1!==[9,13,32,27].indexOf(o)){for(var r=n.target||n.srcElement,a=-1,c=0;c<S.length;c++)if(r===S[c]){a=c;break}9===o?(r=-1===a?w:a===S.length-1?S[0]:S[a+1],O(n),r.focus(),i(r,f.confirmButtonColor)):(r=13===o||32===o?-1===a?w:void 0:27!==o||h.hidden||"none"===h.style.display?void 0:h,void 0!==r&&q(r,n))}}function u(t){var n=t||e.event,o=n.target||n.srcElement,r=n.relatedTarget,a=g(d,"visible");if(a){var i=-1;if(null!==r){for(var c=0;c<S.length;c++)if(r===S[c]){i=c;break}-1===i&&o.focus()}else z=o}}if(void 0===arguments[0])return e.console.error("sweetAlert expects at least 1 attribute!"),!1;var f=r({},m);switch(typeof arguments[0]){case"string":f.title=arguments[0],f.text=arguments[1]||"",f.type=arguments[2]||"";break;case"object":if(void 0===arguments[0].title)return e.console.error('Missing "title" argument!'),!1;f.title=arguments[0].title,f.text=arguments[0].text||m.text,f.type=arguments[0].type||m.type,f.allowOutsideClick=arguments[0].allowOutsideClick||m.allowOutsideClick,f.showCancelButton=void 0!==arguments[0].showCancelButton?arguments[0].showCancelButton:m.showCancelButton,f.closeOnConfirm=void 0!==arguments[0].closeOnConfirm?arguments[0].closeOnConfirm:m.closeOnConfirm,f.closeOnCancel=void 0!==arguments[0].closeOnCancel?arguments[0].closeOnCancel:m.closeOnCancel,f.timer=arguments[0].timer||m.timer,f.confirmButtonText=m.showCancelButton?"Confirm":m.confirmButtonText,f.confirmButtonText=arguments[0].confirmButtonText||m.confirmButtonText,f.confirmButtonColor=arguments[0].confirmButtonColor||m.confirmButtonColor,f.cancelButtonText=arguments[0].cancelButtonText||m.cancelButtonText,f.imageUrl=arguments[0].imageUrl||m.imageUrl,f.imageSize=arguments[0].imageSize||m.imageSize,f.doneFunction=arguments[1]||null;break;default:return e.console.error('Unexpected type of argument! Expected "string" or "object", got '+typeof arguments[0]),!1}n(f),s(),c();for(var d=y(),p=function(t){var n=t||e.event,r=n.target||n.srcElement,a="confirm"===r.className,i=g(d,"visible"),c=f.doneFunction&&"true"===d.getAttribute("data-has-done-function");switch(n.type){case"mouseover":a&&(r.style.backgroundColor=o(f.confirmButtonColor,-.04));break;case"mouseout":a&&(r.style.backgroundColor=f.confirmButtonColor);break;case"mousedown":a&&(r.style.backgroundColor=o(f.confirmButtonColor,-.14));break;case"mouseup":a&&(r.style.backgroundColor=o(f.confirmButtonColor,-.04));break;case"focus":var s=d.querySelector("button.confirm"),u=d.querySelector("button.cancel");a?u.style.boxShadow="none":s.style.boxShadow="none";break;case"click":if(a&&c&&i)f.doneFunction(!0),f.closeOnConfirm&&l();else if(c&&i){var m=String(f.doneFunction).replace(/\s/g,""),y="function("===m.substring(0,9)&&")"!==m.substring(9,10);y&&f.doneFunction(!1),f.closeOnCancel&&l()}else l()}},v=d.querySelectorAll("button"),b=0;b<v.length;b++)v[b].onclick=p,v[b].onmouseover=p,v[b].onmouseout=p,v[b].onmousedown=p,v[b].onfocus=p;A=t.onclick,t.onclick=function(t){var n=t||e.event,o=n.target||n.srcElement,r=d===o,a=k(d,o),i=g(d,"visible"),c="true"===d.getAttribute("data-allow-ouside-click");!r&&!a&&i&&c&&l()};var w=d.querySelector("button.confirm"),h=d.querySelector("button.cancel"),S=d.querySelectorAll("button:not([type=hidden])");M=e.onkeydown,e.onkeydown=a,w.onblur=u,h.onblur=u,e.onfocus=function(){e.setTimeout(function(){void 0!==z&&(z.focus(),z=void 0)},0)}},e.swal.setDefaults=function(e){if(!e)throw new Error("userParams is required");if("object"!=typeof e)throw new Error("userParams has to be a object");r(m,e)},function(){"complete"===t.readyState||"interactive"===t.readyState&&t.body?e.sweetAlertInitialize():t.addEventListener?t.addEventListener("DOMContentLoaded",function n(){t.removeEventListener("DOMContentLoaded",arguments.callee,!1),e.sweetAlertInitialize()},!1):t.attachEvent&&t.attachEvent("onreadystatechange",function(){"complete"===t.readyState&&(t.detachEvent("onreadystatechange",arguments.callee),e.sweetAlertInitialize())})}()}(window,document);
