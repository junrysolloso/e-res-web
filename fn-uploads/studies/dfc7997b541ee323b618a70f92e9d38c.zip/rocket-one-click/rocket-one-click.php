<?php
/*
Plugin Name: Rocket One Click
Plugin URI: http://rocketoneclick.com
Description: One click purchase wordpress plugin for Infusionsoft
Version: 1.9.4
Author: Mark Joseph
Author URI: http://www.infusedaddons.com
*/
define('INFUSEDONECLICK_VER', '1.9.4');
define('INFUSEDONECLICK_DIR', WP_PLUGIN_DIR . "/" . plugin_basename( dirname(__FILE__) ) . '/');
define('INFUSEDONECLICK_URL', plugins_url() . "/" . plugin_basename( dirname(__FILE__) ) . '/');
define('INFUSEDONECLICK_BASE', plugin_basename( __FILE__));
define('INFUSEDONECLICK_UPDATER', 'http://downloads.infusedaddons.com/updater/ioc.php');

// Include Core Files
include(INFUSEDONECLICK_DIR . 'core/core.php');

// Include Admin Files
include(INFUSEDONECLICK_DIR . 'admin/admin.php');

// Include View Files
include(INFUSEDONECLICK_DIR . 'view/view.php');