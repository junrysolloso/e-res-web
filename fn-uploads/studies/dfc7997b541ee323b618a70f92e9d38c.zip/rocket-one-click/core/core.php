<?php  define('IOC_SITE_UNIQUEID',substr(preg_replace("/[^A-Za-z0-9]/",'',NONCE_SALT),0,6));include(INFUSEDONECLICK_DIR.'core/updater.php');$infused_oneclick=array();function ioc_connect_infusion($appname,$apikey=""){global $infused_oneclick;$infusion_apps=get_option('ioc_infusion_apps',array());if(empty($apikey)){$found=false;foreach($infusion_apps as $k =>$app){if($app['appname']==$appname){$apikey=$infusion_apps[$k]['apikey'];$found=true;break;}}if(!$found)return array('status' =>false,'error' =>'Empty API Key','app' =>false);}if(isset($infused_oneclick['app']['appname']))return $infused_oneclick['app']['appname'];if(!class_exists('iaSDK')){include(INFUSEDONECLICK_DIR.'vendor/autoload.php');include INFUSEDONECLICK_DIR.'lib/iasdk/iasdk.php';}$app=new iaSDK;$response=array();try{$app->cfgCon($appname,$apikey);$checker=$app->dsGetSetting('Contact','optiontypes');$pos=strrpos($checker,"ERROR");if($pos ===false){$response['status']=true;$response['error']='';$response['app']=$app;}else{$response['status']=false;$response['error']=$checker;$response['app']=false;}}catch(Exception $e){$response['status']=false;$response['error']=$e->getMessage();$response['app']=false;}$infused_oneclick['app']=array($appname =>$response);return $response;}function ioc_upsell_db_install(){global $wpdb;$ioc_upsell_db_version="1.1";$installed_ver=get_option("ioc_upsell_db_version");if($installed_ver !=$ioc_upsell_db_version){$table_name=$wpdb->prefix."ioc_upsells";$sql="CREATE TABLE $table_name (
		  id mediumint(9) NOT NULL AUTO_INCREMENT,
		  name tinytext NOT NULL,
		  settings longtext NOT NULL,
		  updated datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
		  added datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
		  PRIMARY KEY (id)
		);";require_once(ABSPATH.'wp-admin/includes/upgrade.php');dbDelta($sql);update_option("ioc_upsell_db_version",$ioc_upsell_db_version);}}function ioc_upsell_events_db_install(){global $wpdb;$ioc_upsell_events_db_version="1.0";$installed_ver=get_option("ioc_upsell_events_db_version");if($installed_ver !=$ioc_upsell_events_db_version){$table_name=$wpdb->prefix."ioc_upsell_events";$sql="CREATE TABLE $table_name (
		  id mediumint(9) NOT NULL AUTO_INCREMENT,
		  eventtype tinytext NOT NULL,
		  upsellid mediumint(9) NOT NULL,
		  contactid mediumint(9) NOT NULL,
		  added datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
		  custom text NOT NULL,
		  PRIMARY KEY (id)
		);";require_once(ABSPATH.'wp-admin/includes/upgrade.php');dbDelta($sql);update_option("ioc_upsell_events_db_version",$ioc_upsell_events_db_version);}}function ioc_smartlinks_db_install(){global $wpdb;$ioc_smartlinks_db_version="1.0";$installed_ver=get_option("ioc_smartlinks_db_version");if($installed_ver !=$ioc_smartlinks_db_version){$table_name=$wpdb->prefix."ioc_smartlinks";$sql="CREATE TABLE $table_name (
		  id mediumint(9) NOT NULL AUTO_INCREMENT,
		  app tinytext NOT NULL,
		  title tinytext NOT NULL,
		  settings text NOT NULL,
		  added datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
		  changed datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
		  PRIMARY KEY (id)
		);";require_once(ABSPATH.'wp-admin/includes/upgrade.php');dbDelta($sql);update_option("ioc_smartlinks_db_version",$ioc_smartlinks_db_version);}}function ioc_fetch_upsell($upsellid){global $wpdb;$ioc_upsells=$wpdb->prefix."ioc_upsells";$upsell=$wpdb->get_results("
			SELECT * 
			FROM `$ioc_upsells`
			WHERE `id` = '$upsellid'
		",ARRAY_A);if(count($upsell)>0){return unserialize($upsell[0]['settings']);}else{return array();}}function ioc_fetch_upsells(){global $wpdb;$ioc_upsells=$wpdb->prefix."ioc_upsells";$upsells=$wpdb->get_results("
			SELECT id, name
			FROM `$ioc_upsells`
			WHERE `name` != ''
			ORDER BY id DESC
		",ARRAY_A);if(count($upsells)>0){return $upsells;}else{return array();}}function ioc_return($arr,$key,$default=""){return isset($arr[$key])?stripslashes($arr[$key]):$default;}function ioc_display($arr,$key,$default=""){echo isset($arr[$key])?stripslashes($arr[$key]):$default;}function ioc_register_event($event_type,$upsellid=0,$contact_id=0,$custom_info="",$more_info=array()){global $wpdb;$ioc_upsell_events=$wpdb->prefix."ioc_upsell_events";$wpdb->insert($ioc_upsell_events,array('eventtype' =>$event_type,'upsellid' =>$upsellid,'added' =>current_time('mysql',1),'contactid' =>$contact_id,'custom' =>$custom_info),array('%s','%s','%s','%s','%s'));}function ioc_notify_purchase($meta){$adv_settings=get_option('ioc_all_settings',array());if($adv_settings['notify_purchases']=='true' &&!empty($adv_settings['notify_email'])){mail($adv_settings['notify_email'],'ROC New Success Purchase',"
				** NEW SUCCESSFUL UPSELL PURCHASE **\n\n	

				Upsell Name: {$meta['upsell_name']}\n
				Date / Time: ".date("Y-m-d H:i:s")." \n\n


				Email: {$meta['email']}\n
				Contact ID: {$meta['contact_id']}\n
				Order ID: {$meta['jobid']}\n\n

				Total Amount: {$meta['total']}\n
			");}}function ioc_notify_error($meta){$adv_settings=get_option('ioc_all_settings',array());if($adv_settings['notify_failures']=='true' &&!empty($adv_settings['notify_email'])){mail($adv_settings['notify_email'],'ROC Failed Transaction',"
				** FAILED TRANSACTION **\n\n	

				Upsell Name: {$meta['upsell_name']}\n
				Date / Time: ".date("Y-m-d H:i:s")." \n\n

				Email: {$meta['email']}\n
				Contact ID: {$meta['contact_id']}\n
				Order ID: {$meta['jobid']}\n\n

				ERROR MESSAGE: {$meta['error']}\n
				Total Amount: {$meta['total']}\n
			");}}function ioc_count_events($eventtype,$upsellid){global $wpdb;$ioc_upsell_events=$wpdb->prefix."ioc_upsell_events";return $wpdb->get_var("SELECT COUNT(*) FROM $ioc_upsell_events WHERE eventtype = '$eventtype' AND upsellid = $upsellid");}ioc_upsell_db_install();ioc_upsell_events_db_install();ioc_smartlinks_db_install();