#
# TABLE STRUCTURE FOR: tbl_advisers
#

DROP TABLE IF EXISTS `tbl_advisers`;

CREATE TABLE `tbl_advisers` (
  `adviser_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `adviser_name` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`adviser_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_advisers` (`adviser_id`, `adviser_name`) VALUES (1, 'Jhesorley Laid');
INSERT INTO `tbl_advisers` (`adviser_id`, `adviser_name`) VALUES (3, 'jerson maneja');


#
# TABLE STRUCTURE FOR: tbl_auth_attempts
#

DROP TABLE IF EXISTS `tbl_auth_attempts`;

CREATE TABLE `tbl_auth_attempts` (
  `auth_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `auth_attempts` tinyint(1) NOT NULL,
  `auth_blocked` datetime NOT NULL,
  `auth_user` char(10) DEFAULT NULL,
  PRIMARY KEY (`auth_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_categories
#

DROP TABLE IF EXISTS `tbl_categories`;

CREATE TABLE `tbl_categories` (
  `category_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_categories` (`category_id`, `category_name`) VALUES (1, 'information technology');
INSERT INTO `tbl_categories` (`category_id`, `category_name`) VALUES (2, 'biology');
INSERT INTO `tbl_categories` (`category_id`, `category_name`) VALUES (3, 'business administration');
INSERT INTO `tbl_categories` (`category_id`, `category_name`) VALUES (5, 'general science');


#
# TABLE STRUCTURE FOR: tbl_logs
#

DROP TABLE IF EXISTS `tbl_logs`;

CREATE TABLE `tbl_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_date` datetime NOT NULL DEFAULT current_timestamp(),
  `log_task` varchar(60) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=183 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (1, '2021-04-22 15:05:46', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (2, '2021-04-22 15:06:39', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (3, '2021-04-22 15:07:31', 'Updated user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (4, '2021-04-22 15:07:34', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (5, '2021-04-22 15:07:40', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (6, '2021-04-22 15:29:03', 'Backup database', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (7, '2021-04-22 15:33:14', 'Backup database', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (8, '2021-04-22 16:28:35', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (9, '2021-04-22 16:40:56', 'Updated category', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (10, '2021-04-22 16:41:16', 'Updated category', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (11, '2021-04-22 16:41:34', 'Updated category', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (12, '2021-04-22 16:41:51', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (13, '2021-04-22 16:42:46', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (14, '2021-04-22 16:43:03', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (15, '2021-04-22 16:43:40', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (16, '2021-04-22 16:43:55', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (17, '2021-04-22 16:44:02', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (18, '2021-04-22 16:44:03', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (19, '2021-04-22 16:44:24', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (20, '2021-04-22 16:44:36', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (21, '2021-04-22 16:45:04', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (22, '2021-04-22 16:45:12', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (23, '2021-04-22 16:45:19', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (24, '2021-04-22 16:45:39', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (25, '2021-04-22 17:14:27', 'Added category', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (26, '2021-04-22 17:15:00', 'Deleted category', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (27, '2021-04-22 17:15:11', 'Added category', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (28, '2021-04-22 18:08:47', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (29, '2021-04-22 18:17:04', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (30, '2021-04-22 18:18:49', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (31, '2021-04-22 18:40:49', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (32, '2021-04-22 19:35:27', 'C', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (33, '2021-04-22 20:26:58', 'C', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (34, '2021-04-22 20:28:55', 'Added study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (35, '2021-04-22 20:44:19', 'Deleted study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (36, '2021-04-22 20:44:23', 'Deleted study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (37, '2021-04-22 20:45:56', 'Deleted study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (38, '2021-04-22 20:47:28', 'Added study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (39, '2021-04-22 21:46:34', 'Updated study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (40, '2021-04-22 21:47:55', 'Updated study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (41, '2021-04-22 21:49:01', 'Updated study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (42, '2021-04-22 21:49:15', 'Updated study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (43, '2021-04-22 21:49:35', 'Updated study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (44, '2021-04-22 21:51:06', 'Updated study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (45, '2021-04-22 21:52:06', 'Updated study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (46, '2021-04-22 21:53:18', 'Updated study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (47, '2021-04-22 21:53:48', 'Updated study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (48, '2021-04-22 21:56:00', 'Updated study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (49, '2021-04-22 21:56:50', 'Updated study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (50, '2021-04-22 21:57:16', 'Updated study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (51, '2021-04-22 22:34:58', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (52, '2021-04-22 22:35:49', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (53, '2021-04-22 22:35:52', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (54, '2021-04-22 22:37:02', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (55, '2021-04-23 01:28:06', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (56, '2021-04-23 01:29:03', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (57, '2021-04-23 13:59:19', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (58, '2021-04-23 14:15:45', 'Added adviser', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (59, '2021-04-23 14:26:31', 'Updated adviser', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (60, '2021-04-23 14:26:40', 'Updated adviser', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (61, '2021-04-23 14:27:21', 'Deleted adviser', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (62, '2021-04-23 14:27:34', 'Added adviser', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (63, '2021-04-23 14:44:22', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (64, '2021-04-23 14:44:28', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (65, '2021-04-23 14:47:02', 'Added user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (66, '2021-04-23 14:47:04', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (67, '2021-04-23 14:47:09', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (68, '2021-04-23 14:47:18', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (69, '2021-04-23 14:47:48', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (70, '2021-04-23 14:57:58', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (71, '2021-04-23 14:58:04', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (72, '2021-04-23 14:58:12', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (73, '2021-04-23 15:11:50', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (74, '2021-04-23 15:11:56', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (75, '2021-04-23 16:25:09', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (76, '2021-04-23 18:13:18', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (77, '2021-04-23 18:24:49', 'Added study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (78, '2021-04-23 18:25:20', 'Updated study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (79, '2021-04-23 21:50:05', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (80, '2021-04-23 21:55:45', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (81, '2021-04-23 21:55:56', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (82, '2021-05-10 13:12:15', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (83, '2021-05-10 13:13:15', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (84, '2021-05-10 13:13:49', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (85, '2021-05-10 13:13:57', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (86, '2021-05-10 13:15:41', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (87, '2021-05-10 13:16:04', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (88, '2021-05-10 13:21:47', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (89, '2021-05-10 13:56:20', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (90, '2021-05-10 15:21:41', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (91, '2021-05-10 15:34:58', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (92, '2021-05-10 15:41:19', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (93, '2021-05-10 15:57:37', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (94, '2021-05-10 15:58:47', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (95, '2021-05-10 16:01:06', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (96, '2021-05-10 16:03:26', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (97, '2021-05-10 16:03:42', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (98, '2021-05-10 16:04:34', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (99, '2021-05-10 16:04:42', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (100, '2021-05-10 16:05:24', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (101, '2021-05-10 16:05:51', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (102, '2021-05-10 16:06:03', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (103, '2021-05-10 16:06:10', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (104, '2021-05-10 16:07:16', 'Updated user', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (105, '2021-05-10 16:16:14', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (106, '2021-05-10 16:17:53', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (107, '2021-05-10 16:19:55', 'Updated user', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (108, '2021-05-10 16:20:03', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (109, '2021-05-10 16:20:43', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (110, '2021-05-10 16:26:59', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (111, '2021-05-10 16:30:27', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (112, '2021-05-10 16:30:35', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (113, '2021-05-10 16:30:50', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (114, '2021-05-11 01:59:31', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (115, '2021-05-11 02:00:29', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (116, '2021-05-15 16:56:35', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (117, '2021-05-15 16:59:07', 'Updated category', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (118, '2021-05-15 16:59:13', 'Updated category', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (119, '2021-05-15 16:59:24', 'Added adviser', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (120, '2021-05-15 16:59:33', 'Updated adviser', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (121, '2021-05-15 16:59:36', 'Updated adviser', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (122, '2021-05-15 16:59:43', 'Deleted adviser', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (123, '2021-05-15 16:59:51', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (124, '2021-05-15 17:00:07', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (125, '2021-05-15 17:00:14', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (126, '2021-05-15 17:01:12', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (127, '2021-05-15 17:01:45', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (128, '2021-05-15 17:02:17', 'Backup database', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (129, '2021-05-15 17:02:29', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (130, '2021-05-15 17:08:25', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (131, '2021-05-15 17:27:45', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (132, '2021-05-15 17:27:55', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (133, '2021-05-15 17:32:29', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (134, '2021-05-15 17:35:34', 'Updated study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (135, '2021-05-15 17:35:47', 'Deleted study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (136, '2021-05-15 17:36:11', 'Added adviser', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (137, '2021-05-15 17:36:23', 'Deleted adviser', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (138, '2021-05-15 17:36:39', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (139, '2021-05-15 17:37:53', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (140, '2021-05-15 17:38:28', 'Backup database', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (141, '2021-05-15 17:39:23', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (142, '2021-05-15 17:39:37', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (143, '2021-05-15 17:39:44', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (144, '2021-05-15 17:45:01', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (145, '2021-05-15 23:12:55', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (146, '2021-05-15 23:15:10', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (147, '2021-07-04 16:38:59', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (148, '2021-07-04 19:11:06', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (149, '2021-07-04 19:22:16', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (150, '2021-08-02 12:49:23', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (151, '2021-08-02 12:49:35', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (152, '2021-08-14 19:54:25', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (153, '2021-08-14 19:55:40', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (154, '2021-08-15 19:51:32', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (155, '2021-11-15 19:37:28', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (156, '2021-11-15 19:39:31', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (157, '2021-11-15 19:42:47', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (158, '2021-11-15 19:48:18', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (159, '2021-11-15 19:48:21', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (160, '2021-11-15 19:48:45', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (161, '2021-11-15 19:48:48', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (162, '2021-11-15 19:49:13', 'Updated user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (163, '2021-11-15 19:49:18', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (164, '2021-11-15 19:49:31', 'Log in', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (165, '2021-11-15 19:51:42', 'Log out', 7);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (166, '2021-11-18 07:57:23', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (167, '2021-11-18 08:00:01', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (168, '2021-11-18 08:04:24', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (169, '2021-11-18 08:13:27', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (170, '2021-11-18 08:16:13', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (171, '2021-11-18 08:19:19', 'Backup database', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (172, '2021-11-18 08:19:23', 'Backup database', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (173, '2021-11-18 08:20:52', 'Backup database', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (174, '2021-11-18 08:22:36', 'Backup database', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (175, '2021-11-18 08:25:59', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (176, '2021-11-18 09:09:10', 'Viewed user', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (177, '2021-11-18 09:20:42', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (178, '2021-11-18 10:13:47', 'Updated study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (179, '2021-11-18 10:17:34', 'Added study', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (180, '2021-11-18 11:24:11', 'Log out', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (181, '2021-11-18 11:31:37', 'Log in', 1);
INSERT INTO `tbl_logs` (`log_id`, `log_date`, `log_task`, `user_id`) VALUES (182, '2021-11-18 12:09:38', 'Log out', 1);


#
# TABLE STRUCTURE FOR: tbl_migrations
#

DROP TABLE IF EXISTS `tbl_migrations`;

CREATE TABLE `tbl_migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_migrations` (`version`) VALUES ('1');


#
# TABLE STRUCTURE FOR: tbl_sessions
#

DROP TABLE IF EXISTS `tbl_sessions`;

CREATE TABLE `tbl_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0ghqibhlm5m05bokn1q3n5oc3874upcp', '127.0.0.1', 1637197709, '__ci_last_regenerate|i:1637197709;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"7\";s:11:\"login_level\";s:4:\"user\";s:10:\"user_fname\";s:5:\"brand\";s:10:\"user_photo\";s:36:\"ed46942e4b12e32639b8f9980ca38342.jpg\";s:8:\"log_date\";s:19:\"2021-11-15 19:49:31\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1ft6mu2qfq3dgl13fbpfl9b363uurko0', '127.0.0.1', 1637203017, '__ci_last_regenerate|i:1637203017;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2l9pupesc79e3jadpkpcejilu9kc7k42', '127.0.0.1', 1637205489, '__ci_last_regenerate|i:1637205489;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2lmhjrsnofjgcfg301b047fvrtfcv525', '127.0.0.1', 1637206465, '__ci_last_regenerate|i:1637206465;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 10:13:47\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3g69u8qne77inc03i6af2fqo6j85il3e', '127.0.0.1', 1637205185, '__ci_last_regenerate|i:1637205185;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4fq2pv41gqado7mdpv5dg6nd3rlprdbk', '127.0.0.1', 1637197842, '__ci_last_regenerate|i:1637197709;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"7\";s:11:\"login_level\";s:4:\"user\";s:10:\"user_fname\";s:5:\"brand\";s:10:\"user_photo\";s:36:\"ed46942e4b12e32639b8f9980ca38342.jpg\";s:8:\"log_date\";s:19:\"2021-11-15 19:49:31\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('66da7fvhb15aici01835dhbti5hskneq', '127.0.0.1', 1637206164, '__ci_last_regenerate|i:1637206164;');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6l8qtka2m6nvd6bem96ii7ra4lnvfnv5', '127.0.0.1', 1637197076, '__ci_last_regenerate|i:1637197076;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"7\";s:11:\"login_level\";s:4:\"user\";s:10:\"user_fname\";s:5:\"brand\";s:10:\"user_photo\";s:36:\"ed46942e4b12e32639b8f9980ca38342.jpg\";s:8:\"log_date\";s:19:\"2021-11-15 19:49:31\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7lga0s1c0nak4ov8l63hokfi1bg4rsrf', '127.0.0.1', 1637196369, '__ci_last_regenerate|i:1637196369;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"7\";s:11:\"login_level\";s:4:\"user\";s:10:\"user_fname\";s:5:\"brand\";s:10:\"user_photo\";s:36:\"ed46942e4b12e32639b8f9980ca38342.jpg\";s:8:\"log_date\";s:19:\"2021-11-15 19:49:31\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('94p0grii3o1fkkeh0ensaskqgg52dphj', '127.0.0.1', 1637200123, '__ci_last_regenerate|i:1637200123;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9o40if603c5lqh0cmeuv94b46856skde', '127.0.0.1', 1637201946, '__ci_last_regenerate|i:1637201946;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9spig7fed8belhdm5qcige9s28o9g745', '127.0.0.1', 1637201014, '__ci_last_regenerate|i:1637201014;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9tbferge9m1u0givesnv45mh6bsqrji1', '127.0.0.1', 1637195666, '__ci_last_regenerate|i:1637195666;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"7\";s:11:\"login_level\";s:4:\"user\";s:10:\"user_fname\";s:5:\"brand\";s:10:\"user_photo\";s:36:\"ed46942e4b12e32639b8f9980ca38342.jpg\";s:8:\"log_date\";s:19:\"2021-11-15 19:49:31\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('atu8imu3a6jrarm84un0ffik878j709r', '127.0.0.1', 1637204152, '__ci_last_regenerate|i:1637204152;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('avfic9jg45n1lsblg2fq2ggfo0a7nvn9', '127.0.0.1', 1637205790, '__ci_last_regenerate|i:1637205790;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b7qv8cn71rdlac9i6l06p4i4duan411m', '127.0.0.1', 1637195159, '__ci_last_regenerate|i:1637195159;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"7\";s:11:\"login_level\";s:4:\"user\";s:10:\"user_fname\";s:5:\"brand\";s:10:\"user_photo\";s:36:\"ed46942e4b12e32639b8f9980ca38342.jpg\";s:8:\"log_date\";s:19:\"2021-11-15 19:49:31\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bdqf3uqe502gii1cu26h806ge1hv5d69', '127.0.0.1', 1637199448, '__ci_last_regenerate|i:1637199448;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d5v57f0trakq6drohfud2eusfrhidikt', '127.0.0.1', 1637204554, '__ci_last_regenerate|i:1637204554;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ee485obdu6dplh47f49ktn23p29s5vdo', '127.0.0.1', 1637201619, '__ci_last_regenerate|i:1637201619;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hq6s8vr5l5n8rke0hj5jomkgbkn4t4ha', '127.0.0.1', 1637203394, '__ci_last_regenerate|i:1637203394;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l4ebbncpup0u2m0mrmrffe1vn04da8cg', '127.0.0.1', 1637200709, '__ci_last_regenerate|i:1637200709;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ls6rogleiio924dkvuj2t0f2u3dl2mgn', '127.0.0.1', 1637199099, '__ci_last_regenerate|i:1637199099;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m2ruqm2ps2dr7giqd48tank8pb87g6gg', '127.0.0.1', 1637204855, '__ci_last_regenerate|i:1637204855;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nklm7pcspq5icfjuk7qg4fmuafgqs132', '127.0.0.1', 1637206767, '__ci_last_regenerate|i:1637206767;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 10:13:47\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nt45ru3bun8iopit2sbsac6ng75hk0n7', '127.0.0.1', 1637195980, '__ci_last_regenerate|i:1637195980;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"7\";s:11:\"login_level\";s:4:\"user\";s:10:\"user_fname\";s:5:\"brand\";s:10:\"user_photo\";s:36:\"ed46942e4b12e32639b8f9980ca38342.jpg\";s:8:\"log_date\";s:19:\"2021-11-15 19:49:31\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pv31s4662i9fddj09qda5dq22ku493iu', '127.0.0.1', 1637203727, '__ci_last_regenerate|i:1637203727;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qplmeqg4909uiftm840ulhgm3egf86am', '127.0.0.1', 1637197404, '__ci_last_regenerate|i:1637197404;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"7\";s:11:\"login_level\";s:4:\"user\";s:10:\"user_fname\";s:5:\"brand\";s:10:\"user_photo\";s:36:\"ed46942e4b12e32639b8f9980ca38342.jpg\";s:8:\"log_date\";s:19:\"2021-11-15 19:49:31\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qpnspqrkg659un5i7vuuu8u4a41m6hhm', '127.0.0.1', 1637207850, '__ci_last_regenerate|i:1637207850;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 10:13:47\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qvfa76r30o6iqvvj9ophcuiutmrrp47q', '127.0.0.1', 1637199813, '__ci_last_regenerate|i:1637199813;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r6h90cgbat3ha9sc8i8m7rtpfrr3onr6', '127.0.0.1', 1637194521, '__ci_last_regenerate|i:1637194521;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"7\";s:11:\"login_level\";s:4:\"user\";s:10:\"user_fname\";s:5:\"brand\";s:10:\"user_photo\";s:36:\"ed46942e4b12e32639b8f9980ca38342.jpg\";s:8:\"log_date\";s:19:\"2021-11-15 19:49:31\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ragvs54mgacup6p5l7kh48ffemju500e', '127.0.0.1', 1637194850, '__ci_last_regenerate|i:1637194850;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"7\";s:11:\"login_level\";s:4:\"user\";s:10:\"user_fname\";s:5:\"brand\";s:10:\"user_photo\";s:36:\"ed46942e4b12e32639b8f9980ca38342.jpg\";s:8:\"log_date\";s:19:\"2021-11-15 19:49:31\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rn4ps8e3aup6q3tr392u4nmg497vk0dt', '127.0.0.1', 1637201316, '__ci_last_regenerate|i:1637201316;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('so2lgr2ou07f152irqn7bof7iphurgra', '127.0.0.1', 1637208417, '__ci_last_regenerate|i:1637208417;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 10:13:47\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ucs6bashjmgc7t2bodk50sqstcd8lt16', '127.0.0.1', 1637196760, '__ci_last_regenerate|i:1637196760;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"7\";s:11:\"login_level\";s:4:\"user\";s:10:\"user_fname\";s:5:\"brand\";s:10:\"user_photo\";s:36:\"ed46942e4b12e32639b8f9980ca38342.jpg\";s:8:\"log_date\";s:19:\"2021-11-15 19:49:31\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v7eisn8uikdkklie1b0uv87tun9ngkgk', '127.0.0.1', 1637198792, '__ci_last_regenerate|i:1637198792;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 08:22:36\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v7tk0bnovcnlildu51r586st0u94ft5f', '127.0.0.1', 1637207077, '__ci_last_regenerate|i:1637207077;user_id|s:1:\"1\";user_name|s:12:\"System Admin\";user_role|s:13:\"administrator\";user_photo|s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";recents|a:1:{i:0;O:8:\"stdClass\":5:{s:7:\"user_id\";s:1:\"1\";s:11:\"login_level\";s:13:\"administrator\";s:10:\"user_fname\";s:12:\"system admin\";s:10:\"user_photo\";s:36:\"67dbe4027ef59a2cb95a436f25155d30.jpg\";s:8:\"log_date\";s:19:\"2021-11-18 10:13:47\";}}');


#
# TABLE STRUCTURE FOR: tbl_studies
#

DROP TABLE IF EXISTS `tbl_studies`;

CREATE TABLE `tbl_studies` (
  `study_id` int(11) NOT NULL AUTO_INCREMENT,
  `study_title` varchar(255) NOT NULL,
  `study_year` varchar(32) NOT NULL,
  `study_proponents` varchar(500) NOT NULL,
  `study_abstract` longtext NOT NULL,
  `study_link` varchar(255) NOT NULL,
  `category_id` smallint(6) NOT NULL,
  `adviser_id` smallint(6) NOT NULL,
  PRIMARY KEY (`study_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_studies` (`study_id`, `study_title`, `study_year`, `study_proponents`, `study_abstract`, `study_link`, `category_id`, `adviser_id`) VALUES (4, 'ordering system', '2018', 'junry solloso', '&lt;h3 style=&quot;margin: 15px 0px; padding: 0px; font-weight: 700; font-size: 14px; font-family: &quot;Open Sans&quot;, Arial, sans-serif;&quot;&gt;The standard Lorem Ipsum passage, used since the 1500s&lt;/h3&gt;&lt;p style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;&quot;&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.&lt;/p&gt;&lt;h3 style=&quot;margin: 15px 0px; padding: 0px; font-weight: 700; font-size: 14px; font-family: &quot;Open Sans&quot;, Arial, sans-serif;&quot;&gt;Section 1.10.32 of &quot;de Finibus Bonorum et Malorum&quot;, written by Cicero in 45 BC&lt;/h3&gt;&lt;p style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;&quot;&gt;Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?&lt;/p&gt;&lt;h3 style=&quot;margin: 15px 0px; padding: 0px; font-weight: 700; font-size: 14px; font-family: &quot;Open Sans&quot;, Arial, sans-serif;&quot;&gt;1914 translation by H. Rackham&lt;/h3&gt;&lt;p style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;&quot;&gt;But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?&lt;/p&gt;&lt;h3 style=&quot;margin: 15px 0px; padding: 0px; font-weight: 700; font-size: 14px; font-family: &quot;Open Sans&quot;, Arial, sans-serif;&quot;&gt;Section 1.10.33 of &quot;de Finibus Bonorum et Malorum&quot;, written by Cicero in 45 BC&lt;/h3&gt;&lt;p style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;&quot;&gt;At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.&lt;/p&gt;&lt;h3 style=&quot;margin: 15px 0px; padding: 0px; font-weight: 700; font-size: 14px; font-family: &quot;Open Sans&quot;, Arial, sans-serif;&quot;&gt;1914 translation by H. Rackham&lt;/h3&gt;&lt;p style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;&quot;&gt;On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains.&lt;/p&gt;', 'dfc7997b541ee323b618a70f92e9d38c.zip', 5, 1);
INSERT INTO `tbl_studies` (`study_id`, `study_title`, `study_year`, `study_proponents`, `study_abstract`, `study_link`, `category_id`, `adviser_id`) VALUES (6, 'any system', '2019', 'brand solloso', '&lt;h3 open=&quot;&quot; sans&quot;,=&quot;&quot; arial,=&quot;&quot; sans-serif;&quot;=&quot;&quot; style=&quot;margin: 15px 0px; font-weight: 700; font-size: 14px; padding: 0px;&quot;&gt;The standard Lorem Ipsum passage, used since the 1500s&lt;/h3&gt;&lt;p open=&quot;&quot; sans&quot;,=&quot;&quot; arial,=&quot;&quot; sans-serif;=&quot;&quot; font-size:=&quot;&quot; 14px;&quot;=&quot;&quot; style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; color: rgb(0, 0, 0); padding: 0px; text-align: justify;&quot;&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.&lt;/p&gt;&lt;h3 open=&quot;&quot; sans&quot;,=&quot;&quot; arial,=&quot;&quot; sans-serif;&quot;=&quot;&quot; style=&quot;margin: 15px 0px; font-weight: 700; font-size: 14px; padding: 0px;&quot;&gt;Section 1.10.32 of &quot;de Finibus Bonorum et Malorum&quot;, written by Cicero in 45 BC&lt;/h3&gt;&lt;p open=&quot;&quot; sans&quot;,=&quot;&quot; arial,=&quot;&quot; sans-serif;=&quot;&quot; font-size:=&quot;&quot; 14px;&quot;=&quot;&quot; style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; color: rgb(0, 0, 0); padding: 0px; text-align: justify;&quot;&gt;Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?&lt;/p&gt;&lt;h3 open=&quot;&quot; sans&quot;,=&quot;&quot; arial,=&quot;&quot; sans-serif;&quot;=&quot;&quot; style=&quot;margin: 15px 0px; font-weight: 700; font-size: 14px; padding: 0px;&quot;&gt;1914 translation by H. Rackham&lt;/h3&gt;&lt;p open=&quot;&quot; sans&quot;,=&quot;&quot; arial,=&quot;&quot; sans-serif;=&quot;&quot; font-size:=&quot;&quot; 14px;&quot;=&quot;&quot; style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; color: rgb(0, 0, 0); padding: 0px; text-align: justify;&quot;&gt;But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?&lt;/p&gt;&lt;h3 open=&quot;&quot; sans&quot;,=&quot;&quot; arial,=&quot;&quot; sans-serif;&quot;=&quot;&quot; style=&quot;margin: 15px 0px; font-weight: 700; font-size: 14px; padding: 0px;&quot;&gt;Section 1.10.33 of &quot;de Finibus Bonorum et Malorum&quot;, written by Cicero in 45 BC&lt;/h3&gt;&lt;p open=&quot;&quot; sans&quot;,=&quot;&quot; arial,=&quot;&quot; sans-serif;=&quot;&quot; font-size:=&quot;&quot; 14px;&quot;=&quot;&quot; style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; color: rgb(0, 0, 0); padding: 0px; text-align: justify;&quot;&gt;At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.&lt;/p&gt;&lt;h3 open=&quot;&quot; sans&quot;,=&quot;&quot; arial,=&quot;&quot; sans-serif;&quot;=&quot;&quot; style=&quot;margin: 15px 0px; font-weight: 700; font-size: 14px; padding: 0px;&quot;&gt;1914 translation by H. Rackham&lt;/h3&gt;&lt;p open=&quot;&quot; sans&quot;,=&quot;&quot; arial,=&quot;&quot; sans-serif;=&quot;&quot; font-size:=&quot;&quot; 14px;&quot;=&quot;&quot; style=&quot;margin-right: 0px; margin-bottom: 15px; margin-left: 0px; color: rgb(0, 0, 0); padding: 0px; text-align: justify;&quot;&gt;On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains.&lt;/p&gt;', '34c0d603796208e0b7dfeabfe015bc87.zip', 1, 3);


#
# TABLE STRUCTURE FOR: tbl_user_login
#

DROP TABLE IF EXISTS `tbl_user_login`;

CREATE TABLE `tbl_user_login` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `login_name` varchar(20) NOT NULL,
  `login_pass` char(32) NOT NULL,
  `login_level` varchar(25) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_user_login` (`login_id`, `login_name`, `login_pass`, `login_level`, `user_id`) VALUES (1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'administrator', 1);
INSERT INTO `tbl_user_login` (`login_id`, `login_name`, `login_pass`, `login_level`, `user_id`) VALUES (7, 'brand', 'e10adc3949ba59abbe56e057f20f883e', 'user', 7);


#
# TABLE STRUCTURE FOR: tbl_user_meta
#

DROP TABLE IF EXISTS `tbl_user_meta`;

CREATE TABLE `tbl_user_meta` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_fname` varchar(60) NOT NULL,
  `user_phone` varchar(30) NOT NULL,
  `user_email` varchar(30) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `user_photo` varchar(100) NOT NULL,
  `user_bio` text NOT NULL,
  `user_status` char(15) NOT NULL,
  `member_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_user_meta` (`user_id`, `user_fname`, `user_phone`, `user_email`, `user_address`, `user_photo`, `user_bio`, `user_status`, `member_id`) VALUES (1, 'system admin', '+639108973533', 'junry.s.solloso@gmail.com', 'san jose, dinagat islands', '67dbe4027ef59a2cb95a436f25155d30.jpg', 'hobbyist and enthusiast programmer.', 'active', 0);
INSERT INTO `tbl_user_meta` (`user_id`, `user_fname`, `user_phone`, `user_email`, `user_address`, `user_photo`, `user_bio`, `user_status`, `member_id`) VALUES (4, 'jhesorley laid', '09090909000', 'jhes@gmail.com', 'san jose, dinagat islands', 'ab5ec9a08a148a11f65947cf4d0b34dc.jpg', 'na', 'active', 0);
INSERT INTO `tbl_user_meta` (`user_id`, `user_fname`, `user_phone`, `user_email`, `user_address`, `user_photo`, `user_bio`, `user_status`, `member_id`) VALUES (5, 'jinky mibato', '09090909000', 'jinky@gmail.com', 'san juan, san jose, dinagat islands', 'f629cc5b7b4db51d638b89258bb5123d.jpg', 'pharmacist', 'active', 0);
INSERT INTO `tbl_user_meta` (`user_id`, `user_fname`, `user_phone`, `user_email`, `user_address`, `user_photo`, `user_bio`, `user_status`, `member_id`) VALUES (6, 'bing de los santos', '09186751050', 'bingdelossatos83@gmail.com', 'p-1 poblation san jose dinagat islands', 'ac3bfac6263dd5ff4734e5fc3a5bdc62.jpg', 'n/a', 'active', 0);
INSERT INTO `tbl_user_meta` (`user_id`, `user_fname`, `user_phone`, `user_email`, `user_address`, `user_photo`, `user_bio`, `user_status`, `member_id`) VALUES (7, 'brand', '00000000000', 'brand@gmail.com', 'san jose', 'ed46942e4b12e32639b8f9980ca38342.jpg', 'na', 'active', 0);


